

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-primary text-white">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-center">
                <h2 class="mb-3 mb-md-0 fs-4"><i class="fas fa-truck me-2"></i>Gestión de Proveedores</h2>
                <a href="<?php echo e(route('proveedores.create')); ?>" class="btn btn-light btn-sm">
                    <i class="fas fa-plus me-2"></i>Añadir nuevo proveedor
                </a>
            </div>
        </div>
        <div class="card-body">
            <div id="alert-container">
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert" id="success-alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert" id="error-alert">
                        <?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
            </div>

            <?php if($proveedores->isEmpty()): ?>
                <p class="text-muted fs-5 text-center">No hay proveedores registrados.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Nombre</th>
                                <th>Contacto</th>
                                <th>Teléfono</th>
                                <th>Email</th>
                                <th class="text-center">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proveedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($proveedor->nombre); ?></td>
                                    <td><?php echo e($proveedor->contacto); ?></td>
                                    <td><?php echo e($proveedor->telefono); ?></td>
                                    <td><?php echo e($proveedor->email); ?></td>
                                    <td>
                                        <div class="d-flex justify-content-center">
                                            <a href="<?php echo e(route('proveedores.show', $proveedor->id)); ?>" class="btn btn-outline-info btn-sm me-2">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="<?php echo e(route('proveedores.edit', $proveedor->id)); ?>" class="btn btn-outline-warning btn-sm me-2">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <form action="<?php echo e(route('proveedores.destroy', $proveedor->id)); ?>" method="POST" class="d-inline delete-form">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-outline-danger btn-sm">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="d-flex justify-content-center mt-4">
                    <?php echo e($proveedores->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const deleteForms = document.querySelectorAll('.delete-form');
        deleteForms.forEach(form => {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                if (confirm('¿Estás seguro de que quieres eliminar este proveedor?')) {
                    this.submit();
                }
            });
        });

        function handleAlert(alertId) {
            const alert = document.getElementById(alertId);
            if (alert) {
                setTimeout(function() {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                }, 3000);
            }
        }

        handleAlert('success-alert');
        handleAlert('error-alert');
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/inventariohidroo/public_html/resources/views/proveedores/index.blade.php ENDPATH**/ ?>