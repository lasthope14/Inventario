<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="row mb-4">
        <div class="col-12">
            <div class="card bg-light shadow-sm">
                <div class="card-body py-3">
                    <h1 class="h4 font-weight-bold mb-0 text-gray-800 text-center">Inventario de Herramientas, Materiales y Equipos</h1>
                </div>
            </div>
        </div>
    </div>

    <!-- Estadísticas principales -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="<?php echo e(route('inventarios.index')); ?>" class="text-decoration-none">
                <div class="card border-left-primary shadow h-100">
                    <div class="card-body">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-2">Total Inventario</div>
                        <div class="row no-gutters align-items-center">
                            <div class="col">
                                <div class="h2 mb-0 font-weight-bold text-gray-800 text-center"><?php echo e($total_inventario); ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-boxes fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="<?php echo e(route('inventarios.index', ['estado' => 'disponible'])); ?>" class="text-decoration-none">
                <div class="card border-left-success shadow h-100">
                    <div class="card-body">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-2">Disponibles</div>
                        <div class="row no-gutters align-items-center">
                            <div class="col">
                                <div class="h2 mb-0 font-weight-bold text-gray-800 text-center"><?php echo e($disponibles); ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-check fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="<?php echo e(route('inventarios.index', ['estado' => 'en uso'])); ?>" class="text-decoration-none">
                <div class="card border-left-info shadow h-100">
                    <div class="card-body">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-2">En Uso</div>
                        <div class="row no-gutters align-items-center">
                            <div class="col">
                                <div class="h2 mb-0 font-weight-bold text-gray-800 text-center"><?php echo e($en_uso); ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-user fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="<?php echo e(route('inventarios.index', ['estado' => 'en mantenimiento'])); ?>" class="text-decoration-none">
                <div class="card border-left-warning shadow h-100">
                    <div class="card-body">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-2">En Mantenimiento</div>
                        <div class="row no-gutters align-items-center">
                            <div class="col">
                                <div class="h2 mb-0 font-weight-bold text-gray-800 text-center"><?php echo e($en_mantenimiento); ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-tools fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-xl-6 col-md-6 mb-4">
            <a href="<?php echo e(route('mantenimientos.index', ['filtro' => 'realizados'])); ?>" class="text-decoration-none">
                <div class="card border-left-secondary shadow h-100">
                    <div class="card-body">
                        <div class="text-xs font-weight-bold text-secondary text-uppercase mb-2">Mantenimientos Realizados</div>
                        <div class="row no-gutters align-items-center">
                            <div class="col">
                                <div class="h2 mb-0 font-weight-bold text-gray-800 text-center"><?php echo e($mantenimientos_realizados); ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-cogs fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-xl-6 col-md-6 mb-4">
            <div class="card border-left-dark shadow h-100">
                <div class="card-body">
                    <div class="text-xs font-weight-bold text-dark text-uppercase mb-2">Valor Total Inventario</div>
                    <div class="row no-gutters align-items-center">
                        <div class="col">
                            <div class="h2 mb-0 font-weight-bold text-gray-800 text-center">$<?php echo e(number_format($valor_total_inventario, 2)); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Gráficos y Tablas -->
    <div class="row">
        <div class="col-xl-6 col-lg-6 mb-3">
            <div class="card shadow">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Inventario por Ubicación</h6>
                </div>
                <div class="card-body">
                    <div class="chart-area" style="height: 250px;">
                        <canvas id="barChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-6 col-lg-6 mb-3">
            <div class="card shadow">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Estado de Mantenimientos</h6>
                </div>
                <div class="card-body">
                    <div class="chart-pie" style="height: 250px;">
                        <canvas id="pieChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Tablas -->
    <div class="row">
        <div class="col-xl-6 mb-3">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><i class="fas fa-calendar-alt mr-2"></i>Próximos Mantenimientos</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover" width="100%" cellspacing="0">
                            <thead class="thead-light">
                                <tr class="text-center">
                                    <th><i class="fas fa-tools mr-1"></i>Equipo</th>
                                    <th><i class="far fa-calendar mr-1"></i>Fecha</th>
                                    <th><i class="fas fa-tag mr-1"></i>Tipo</th>
                                    <th><i class="fas fa-user mr-1"></i>Solicitado por</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $proximos_mantenimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mantenimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td class="text-wrap"><a href="<?php echo e(route('mantenimientos.show', $mantenimiento->id)); ?>"><strong><?php echo e($mantenimiento->inventario->nombre); ?></strong></a></td>
                                    <td><?php echo e($mantenimiento->fecha_programada->format('d/m/Y')); ?></td>
                                    <td><?php echo e(ucfirst($mantenimiento->tipo)); ?></td>
                                    <td class="text-wrap"><?php echo e($mantenimiento->solicitadoPor ? $mantenimiento->solicitadoPor->name : 'No asignado'); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
       
        <div class="col-xl-6 mb-3">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><i class="fas fa-exchange-alt mr-2"></i>Últimos Movimientos</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover" width="100%" cellspacing="0">
                            <thead class="thead-light">
                                <tr class="text-center">
                                    <th><i class="fas fa-box mr-1"></i>Equipo</th>
                                    <th><i class="far fa-calendar mr-1"></i>Fecha</th>
                                    <th><i class="fas fa-map-marker-alt mr-1"></i>Origen</th>
                                    <th><i class="fas fa-map-marker-alt mr-1"></i>Destino</th>
                                    <th><i class="fas fa-user mr-1"></i>Realizado por</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $movimientos_recientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td class="text-wrap"><a href="<?php echo e(route('inventarios.show', $movimiento->inventario->id)); ?>"><strong><?php echo e($movimiento->inventario->nombre); ?></strong></a></td>
                                    <td><?php echo e($movimiento->fecha_movimiento->format('d/m/Y')); ?></td>
                                    <td class="text-wrap"><?php echo e($movimiento->ubicacionOrigen->nombre); ?></td>
                                    <td class="text-wrap"><?php echo e($movimiento->ubicacionDestino->nombre); ?></td>
                                    <td class="text-wrap"><?php echo e($movimiento->realizadoPor->name); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .card-body {
        flex: 1 1 auto;
        min-height: 1px;
        padding: 1.25rem;
    }
    .text-xs {
        font-size: .8rem;
    }
    .card-header {
        background-color: #f8f9fc;
        border-bottom: 1px solid #e3e6f0;
    }
    .border-left-primary { border-left: .25rem solid #4e73df!important; }
    .border-left-success { border-left: .25rem solid #1cc88a!important; }
    .border-left-info { border-left: .25rem solid #36b9cc!important; }
    .border-left-warning { border-left: .25rem solid #f6c23e!important; }
    .border-left-secondary { border-left: .25rem solid #858796!important; }
    .border-left-dark { border-left: .25rem solid #5a5c69!important; }
    .chart-area, .chart-pie {
        height: 20rem;
        position: relative;
    }
    .table-hover tbody tr:hover {
        background-color: rgba(0,0,0,.075);
    }
    .thead-light th {
        background-color: #f8f9fc;
        color: #5a5c69;
        border-color: #e3e6f0;
    }
    .table-responsive {
        overflow-x: auto;
    }
    .table th, .table td {
        white-space: normal;
        word-wrap: break-word;
    }
    .text-wrap {
        white-space: normal !important;
    }
    .table {
        width: 100% !important;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Datos para las gráficas
    var ubicaciones = <?php echo json_encode($ubicaciones->pluck('cantidad'), 15, 512) ?>;
    var nombresUbicaciones = <?php echo json_encode($ubicaciones->pluck('nombre'), 15, 512) ?>;
    var estadoMantenimientos = [
        <?php echo e($mantenimientos_realizados); ?>,
        <?php echo e($mantenimientos_pendientes); ?>,
        <?php echo e($mantenimientos_vencidos); ?>

    ];
    var etiquetasMantenimientos = ['Realizados', 'Pendientes', 'Vencidos'];

    // Bar Chart - Inventario por Ubicación
    var ctxBar = document.getElementById('barChart').getContext('2d');
    var barChart = new Chart(ctxBar, {
        type: 'bar',
        data: {
            labels: nombresUbicaciones,
            datasets: [{
                label: 'Inventario por Ubicación',
                data: ubicaciones,
                backgroundColor: 'rgba(78, 115, 223, 0.8)',
                borderColor: 'rgba(78, 115, 223, 1)',
                borderWidth: 1
            }]
        },
        options: {
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });

    // Pie Chart - Estado de Mantenimientos
    var ctxPie = document.getElementById('pieChart').getContext('2d');
    var pieChart = new Chart(ctxPie, {
        type: 'doughnut',
        data: {
            labels: etiquetasMantenimientos,
            datasets: [{
                data: estadoMantenimientos,
                backgroundColor: ['#1cc88a', '#f6c23e', '#e74a3b'],
                hoverBackgroundColor: ['#17a673', '#f4b619', '#e02d1b'],
                hoverBorderColor: "rgba(234, 236, 244, 1)",
            }]
        },
        options: {
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right'
                }
            },
            cutout: '60%'
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/inventariohidroo/public_html/resources/views/dashboard.blade.php ENDPATH**/ ?>