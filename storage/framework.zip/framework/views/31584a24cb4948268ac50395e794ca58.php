<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" data-bs-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- Favicons -->
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('assets/favicon.png')); ?>">
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/favicon.ico')); ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('assets/apple-touch-icon.png')); ?>">
    <meta name="msapplication-TileImage" content="<?php echo e(asset('assets/favicon.png')); ?>">
    <meta name="msapplication-TileColor" content="#006D95">
    <meta name="theme-color" content="#006D95">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Flatpickr -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/themes/airbnb.css">

    <!-- Bootstrap CSS (Última versión) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">


    <style>
        /* Estilos Generales */
        body {
            font-family: 'Figtree', 'Segoe UI', 'Helvetica Neue', Arial, sans-serif;
            background-color: #f8f9fa;
        }

        .card {
            border-radius: 10px;
            transition: box-shadow 0.3s ease-in-out, transform 0.3s ease-in-out;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        }

        .table th {
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.75rem;
            letter-spacing: 0.5px;
        }

        .table td {
            font-size: 0.875rem;
        }

        /* Dark Mode Styles */
        [data-bs-theme="dark"] {
            --bs-body-bg: #121212;
            --bs-body-color: #e0e0e0;
        }

        [data-bs-theme="dark"] .dropdown-menu {
            background-color: #2c2c2c;
            color: #ffffff;
        }

        [data-bs-theme="dark"] .dropdown-item {
            color: #ffffff;
        }

        [data-bs-theme="dark"] .dropdown-item:hover {
            background-color: #3a3a3a;
        }

        /* Notifications Badge Animation */
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.2); }
            100% { transform: scale(1); }
        }

        #notification-count {
            animation: pulse 2s infinite;
        }
        /* Estilos para el header fijo en app.blade.php */
.app-content {
    padding-top: 65px;
}

.fixed-header {
    position: fixed;
    top: 65px; /* Altura del navbar */
    left: 0;
    right: 0;
    z-index: 1040;
    background-color: #fff;
}

.header-content {
    margin: 0;
    border-radius: 0;
}

.content-wrapper {
    padding-top: 60px; /* Altura del header fijo */
}

@media (max-width: 767px) {
    .fixed-header {
        top: 56px; /* Altura del navbar en móviles */
    }
}

    </style>
</head>
<body class="font-sans antialiased">
    <div class="min-vh-100 bg-light">
        <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Page Heading -->
        <?php if(isset($header)): ?>
            <header class="bg-white shadow">
                <div class="container-fluid py-6 px-4">
                    <?php echo e($header); ?>

                </div>
            </header>
        <?php endif; ?>

        <!-- Page Content -->
        <main class="container-fluid py-4">
            <?php echo e($slot ?? ''); ?>

            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    
    <?php echo $__env->yieldPushContent('scripts'); ?>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Flatpickr -->
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/es.js"></script>

<script>
    console.log('app.blade.php script started');
    document.addEventListener('DOMContentLoaded', function() {
        console.log('app.blade.php DOMContentLoaded event fired');
        // Inicializar dropdowns
        var dropdownElementList = [].slice.call(document.querySelectorAll('.dropdown-toggle'))
        var dropdownList = dropdownElementList.map(function (dropdownToggleEl) {
            return new bootstrap.Dropdown(dropdownToggleEl)
        });

        function checkNewNotifications() {
            $.get('/check-notifications', function(data) {
                const $count = $('#notification-count, #notification-count-mobile');
                $count.text(data.count > 99 ? '99+' : data.count);
                $count.toggle(data.count > 0);
                
                $.get('/get-notifications', function(notificationsHtml) {
                    $('.notifications-content, .notifications-content-mobile').html(notificationsHtml);
                });
            });
        }

        checkNewNotifications();
        setInterval(checkNewNotifications, 300000); // 5 minutos

        $(document).on('click', '.notification-item a', function(e) {
            e.preventDefault();
            var notificationId = $(this).closest('.notification-item').data('notification-id');
            var link = $(this).attr('href');

            $.ajax({
                url: '/notifications/' + notificationId + '/mark-as-read',
                type: 'POST',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    if(response.success) {
                        window.location.href = link;
                    }
                }
            });
        });

        // Tema oscuro
        function toggleDarkMode() {
            const html = document.documentElement;
            const currentTheme = html.getAttribute('data-bs-theme');
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            html.setAttribute('data-bs-theme', newTheme);
            localStorage.setItem('darkMode', newTheme === 'dark');

            // Actualizar icono
            const themeIcon = document.getElementById('themeIcon');
            if (themeIcon) {
                themeIcon.classList.toggle('fa-sun');
                themeIcon.classList.toggle('fa-moon');
            }
        }

        // Establecer tema inicial
        const darkMode = localStorage.getItem('darkMode') === 'true';
        document.documentElement.setAttribute('data-bs-theme', darkMode ? 'dark' : 'light');

        // Event listeners para cambio de tema
        const themeToggles = document.querySelectorAll('#themeToggle, #themeToggleMobile');
        themeToggles.forEach(toggle => {
            toggle.addEventListener('click', toggleDarkMode);
        });
    });
</script>
</body>
</html><?php /**PATH /home/inventariohidroo/public_html/resources/views/layouts/app.blade.php ENDPATH**/ ?>