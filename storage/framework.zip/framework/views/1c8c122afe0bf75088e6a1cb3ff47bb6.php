

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4"><?php echo e(isset($movimiento) ? 'Editar' : 'Registrar Nuevo'); ?> Movimiento</h1>
    
    <form action="<?php echo e(isset($movimiento) ? route('movimientos.update', $movimiento) : route('movimientos.store')); ?>" method="POST" id="movimientoForm">
        <?php echo csrf_field(); ?>
        <?php if(isset($movimiento)): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>
        <input type="hidden" name="inventario_id" value="<?php echo e($inventario->id); ?>">
        <div class="form-group mb-3">
            <label for="elemento">Elemento</label>
            <input type="text" id="elemento" class="form-control" value="<?php echo e($inventario->nombre); ?> (<?php echo e($inventario->codigo_unico); ?>)" readonly>
        </div>
        <div class="form-group mb-3">
            <label for="ubicacion_origen">Ubicación de Origen</label>
            <select name="ubicacion_origen" id="ubicacion_origen" class="form-control" required>
                <option value="">Seleccione la ubicación de origen</option>
                <?php $__currentLoopData = $ubicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ubicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($ubicacion->id); ?>" <?php echo e((isset($movimiento) && $movimiento->ubicacion_origen == $ubicacion->id) || (!isset($movimiento) && $inventario->ubicacion_id == $ubicacion->id) ? 'selected' : ''); ?>>
                        <?php echo e($ubicacion->nombre); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group mb-3">
            <label for="ubicacion_destino">Ubicación de Destino</label>
            <select name="ubicacion_destino" id="ubicacion_destino" class="form-control" required>
                <option value="">Seleccione la ubicación de destino</option>
                <?php $__currentLoopData = $ubicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ubicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($ubicacion->id); ?>" <?php echo e(isset($movimiento) && $movimiento->ubicacion_destino == $ubicacion->id ? 'selected' : ''); ?>>
                        <?php echo e($ubicacion->nombre); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group mb-3">
            <label for="usuario_origen_id">Empleado de Origen</label>
            <select name="usuario_origen_id" id="usuario_origen_id" class="form-control" required>
                <option value="">Seleccione el empleado de origen</option>
                <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($empleado->id); ?>" <?php echo e(isset($movimiento) && $movimiento->usuario_origen_id == $empleado->id ? 'selected' : ''); ?>>
                        <?php echo e($empleado->nombre); ?> <?php echo e($empleado->cargo ? '- ' . $empleado->cargo : ''); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group mb-3">
            <label for="usuario_destino_id">Empleado de Destino</label>
            <select name="usuario_destino_id" id="usuario_destino_id" class="form-control" required>
                <option value="">Seleccione el empleado de destino</option>
                <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($empleado->id); ?>" <?php echo e(isset($movimiento) && $movimiento->usuario_destino_id == $empleado->id ? 'selected' : ''); ?>>
                        <?php echo e($empleado->nombre); ?> <?php echo e($empleado->cargo ? '- ' . $empleado->cargo : ''); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group mb-3">
            <label for="fecha_movimiento">Fecha y Hora de Movimiento</label>
            <div class="input-group">
                <input type="text" 
                       class="form-control flatpickr" 
                       id="fecha_movimiento" 
                       name="fecha_movimiento" 
                       placeholder="Seleccione fecha y hora"
                       value="<?php echo e(isset($movimiento) ? $movimiento->fecha_movimiento->format('d/m/Y H:i') : ''); ?>"
                       readonly>
                <span class="input-group-text pointer" onclick="document.getElementById('fecha_movimiento').click()">
                    <i class="fas fa-calendar-alt"></i>
                </span>
            </div>
        </div>
        <div class="form-group mb-3">
            <label for="motivo">Motivo</label>
            <textarea name="motivo" id="motivo" class="form-control" rows="3"><?php echo e(isset($movimiento) ? $movimiento->motivo : ''); ?></textarea>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary" id="submitButton">
                <?php echo e(isset($movimiento) ? 'Actualizar' : 'Registrar'); ?> Movimiento
            </button>
            <?php if(isset($movimiento)): ?>
                <a href="<?php echo e(route('movimientos.show', $movimiento->id)); ?>" class="btn btn-secondary">Cancelar</a>
            <?php else: ?>
                <a href="<?php echo e(route('inventarios.show', $inventario->id)); ?>" class="btn btn-secondary">Cancelar</a>
            <?php endif; ?>
        </div>
    </form>
</div>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<style>
    .pointer {
        cursor: pointer;
    }
    .input-group .input-group-text {
        background-color: #fff;
        border-left: none;
    }
    .flatpickr-input {
        background-color: #fff !important;
    }
    .flatpickr-input:focus {
        box-shadow: none !important;
        border-color: #dee2e6 !important;
    }
    .spinner-border {
        width: 1rem;
        height: 1rem;
        border-width: 0.2em;
        margin-right: 0.5rem;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/es.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    flatpickr.localize(flatpickr.l10ns.es);
    
    const config = {
        dateFormat: "d/m/Y H:i",
        enableTime: true,
        time_24hr: true,
        allowInput: false,
        disableMobile: true,
        defaultHour: new Date().getHours(),
        defaultMinute: new Date().getMinutes(),
        locale: {
            firstDayOfWeek: 1,
            weekdays: {
                shorthand: ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'],
                longhand: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado']
            },
            months: {
                shorthand: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
                longhand: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
            }
        }
    };

    document.querySelectorAll('.flatpickr').forEach(function(elem) {
        flatpickr(elem, config);
    });

    // Protección contra doble envío
    const form = document.getElementById('movimientoForm');
    const submitButton = document.getElementById('submitButton');

    form.addEventListener('submit', function(e) {
        if (form.getAttribute('data-submitting')) {
            e.preventDefault();
            return false;
        }

        submitButton.disabled = true;
        form.setAttribute('data-submitting', 'true');
        submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Guardando...';
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/inventariohidroo/public_html/resources/views/movimientos/edit.blade.php ENDPATH**/ ?>