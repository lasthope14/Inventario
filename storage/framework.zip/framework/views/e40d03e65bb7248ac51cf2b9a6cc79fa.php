<!-- Navbar -->
<nav class="navbar navbar-expand-xl navbar-light bg-white shadow-sm">
    <div class="container-fluid px-3 px-xl-5">
        <!-- Logo (siempre visible) -->
        <a class="navbar-brand py-2 logo-container" href="<?php echo e(route('dashboard')); ?>">
            <img src="<?php echo e(asset('assets/logo.png')); ?>" alt="Logo" class="logo-img" style="height: 55px; width: auto;">
        </a>
            
        <!-- Toggler for mobile -->
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar"
                aria-controls="offcanvasNavbar" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Navbar content for desktop -->
        <div class="collapse navbar-collapse" id="navbarContent">
            <!-- Navigation Links -->
            <ul class="navbar-nav mb-2 mb-xl-0 align-items-center">
                <li class="nav-item">
                    <a href="<?php echo e(route('dashboard')); ?>" class="nav-link px-3 <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
                        <i class="fas fa-home me-2"></i><span><?php echo e(__('Inicio')); ?></span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('inventarios.index')); ?>" class="nav-link px-3 <?php echo e(request()->routeIs('inventarios.*') ? 'active' : ''); ?>">
                        <i class="fas fa-box me-2"></i><span><?php echo e(__('Inventario')); ?></span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('movimientos.index')); ?>" class="nav-link px-3 <?php echo e(request()->routeIs('movimientos.*') ? 'active' : ''); ?>">
                        <i class="fas fa-exchange-alt me-2"></i><span><?php echo e(__('Movimientos')); ?></span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('mantenimientos.index')); ?>" class="nav-link px-3 <?php echo e(request()->routeIs('mantenimientos.*') ? 'active' : ''); ?>">
                        <i class="fas fa-tools me-2"></i><span><?php echo e(__('Mantenimientos')); ?></span>
                    </a>
                </li>
                <?php if(auth()->user()->role->name === 'administrador'): ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle px-3" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-cog me-2"></i><span><?php echo e(__('Administración')); ?></span>
                    </a>
                    <ul class="dropdown-menu shadow-sm" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item py-2" href="<?php echo e(route('categorias.index')); ?>"><i class="fas fa-tags me-2"></i><?php echo e(__('Categorías')); ?></a></li>
                        <li><a class="dropdown-item py-2" href="<?php echo e(route('proveedores.index')); ?>"><i class="fas fa-truck me-2"></i><?php echo e(__('Proveedores')); ?></a></li>
                        <li><a class="dropdown-item py-2" href="<?php echo e(route('ubicaciones.index')); ?>"><i class="fas fa-map-marker-alt me-2"></i><?php echo e(__('Ubicaciones')); ?></a></li>
                        <li><a class="dropdown-item py-2" href="<?php echo e(route('empleados.index')); ?>"><i class="fas fa-users me-2"></i><?php echo e(__('Empleados')); ?></a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item py-2" href="<?php echo e(route('admin.users.index')); ?>"><i class="fas fa-user-cog me-2"></i><?php echo e(__('Gestión de Usuarios')); ?></a></li>
                    </ul>
                </li>
                <?php endif; ?>
            </ul>

            <!-- Right Side Navigation -->
            <ul class="navbar-nav align-items-center ms-auto">
                <!-- Notifications -->
                <li class="nav-item dropdown px-2">
                    <a class="nav-link position-relative notification-icon p-0" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <span id="notification-count" class="position-absolute translate-middle badge rounded-pill bg-danger" style="display: none;">
                            0
                        </span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end shadow-sm notifications-dropdown" aria-labelledby="notificationsDropdown">
                        <li><h6 class="dropdown-header">Notificaciones</h6></li>
                        <div class="notifications-content">
                            <!-- El contenido se cargará dinámicamente aquí -->
                        </div>
                        <li><hr class="dropdown-divider m-0"></li>
                        <li><button id="markAllAsReadDesktop" class="dropdown-item text-center py-2">Marcar todas como leídas</button></li>
                    </ul>
                </li>
                <!-- User Menu -->
                <li class="nav-item dropdown px-2">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-user-circle me-2"></i><span><?php echo e(Auth::user()->name); ?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end shadow-sm" aria-labelledby="userDropdown">
                        <li><a class="dropdown-item py-2" href="<?php echo e(route('profile.edit')); ?>"><i class="fas fa-user me-2"></i><?php echo e(__('Perfil')); ?></a></li>
                        <li><hr class="dropdown-divider m-0"></li>
                        <li>
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <a class="dropdown-item py-2" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); this.closest('form').submit();">
                                    <i class="fas fa-sign-out-alt me-2"></i><?php echo e(__('Cerrar Sesión')); ?>

                                </a>
                            </form>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>

        <!-- Offcanvas menu for mobile -->
        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar"
             aria-labelledby="offcanvasNavbarLabel">
            <div class="offcanvas-header border-bottom">
                <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menú</h5>
                <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"
                        aria-label="Close"></button>
            </div>
            <div class="offcanvas-body">
                <!-- User Info -->
                <div class="d-flex align-items-center mb-3 pb-3 border-bottom">
                    <div class="flex-grow-1">
                        <a href="<?php echo e(route('profile.edit')); ?>" class="text-decoration-none text-dark">
                            <h6 class="mb-0"><?php echo e(Auth::user()->name); ?></h6>
                            <small class="text-muted"><?php echo e(Auth::user()->email); ?></small>
                        </a>
                    </div>
                </div>
                <!-- Navigation Links -->
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a href="<?php echo e(route('dashboard')); ?>" class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
                            <i class="fas fa-home me-3"></i><?php echo e(__('Inicio')); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('inventarios.index')); ?>" class="nav-link <?php echo e(request()->routeIs('inventarios.*') ? 'active' : ''); ?>">
                            <i class="fas fa-box me-3"></i><?php echo e(__('Inventario')); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('movimientos.index')); ?>" class="nav-link <?php echo e(request()->routeIs('movimientos.*') ? 'active' : ''); ?>">
                            <i class="fas fa-exchange-alt me-3"></i><?php echo e(__('Movimientos')); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('mantenimientos.index')); ?>" class="nav-link <?php echo e(request()->routeIs('mantenimientos.*') ? 'active' : ''); ?>">
                            <i class="fas fa-tools me-3"></i><?php echo e(__('Mantenimientos')); ?>

                        </a>
                    </li>
                    <?php if(auth()->user()->role->name === 'administrador'): ?>
                    <li class="nav-item">
                        <a class="nav-link dropdown-toggle" href="#adminSubmenu" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="adminSubmenu">
                            <i class="fas fa-cog me-3"></i><?php echo e(__('Administración')); ?>

                        </a>
                        <div class="collapse" id="adminSubmenu">
                            <ul class="navbar-nav ms-3 mt-2">
                                <li><a class="nav-link py-2" href="<?php echo e(route('categorias.index')); ?>"><i class="fas fa-tags me-2"></i><?php echo e(__('Categorías')); ?></a></li>
                                <li><a class="nav-link py-2" href="<?php echo e(route('proveedores.index')); ?>"><i class="fas fa-truck me-2"></i><?php echo e(__('Proveedores')); ?></a></li>
                                <li><a class="nav-link py-2" href="<?php echo e(route('ubicaciones.index')); ?>"><i class="fas fa-map-marker-alt me-2"></i><?php echo e(__('Ubicaciones')); ?></a></li>
                                <li><a class="nav-link py-2" href="<?php echo e(route('empleados.index')); ?>"><i class="fas fa-users me-2"></i><?php echo e(__('Empleados')); ?></a></li>
                                <li><a class="nav-link py-2" href="<?php echo e(route('admin.users.index')); ?>"><i class="fas fa-user-cog me-2"></i><?php echo e(__('Gestión de Usuarios')); ?></a></li>
                            </ul>
                        </div>
                    </li>
                    <?php endif; ?>
                </ul>

                <hr>

                <!-- Notifications -->
                <a href="#" class="d-flex align-items-center mb-3 text-decoration-none text-dark" id="openNotificationsPanel">
                    <i class="fas fa-bell me-3"></i>
                    <span>Notificaciones</span>
                    <span id="notification-count-mobile" class="badge bg-danger rounded-pill ms-auto" style="display: none;">
                        0
                    </span>
                </a>
                
                <!-- Panel deslizable para notificaciones -->
                <div id="notificationsPanel" class="notifications-panel">
                    <div class="notifications-panel-header">
                        <h5>Notificaciones</h5>
                        <button id="closeNotificationsPanel" class="btn-close" aria-label="Close"></button>
                    </div>
                    <div class="notifications-panel-body">
                        <div class="notifications-content-mobile">
                            <!-- El contenido de las notificaciones se cargará aquí dinámicamente -->
                        </div>
                    </div>
                    <div class="notifications-panel-footer">
                        <button id="markAllAsRead" class="btn btn-primary w-100">Marcar todas como leídas</button>
                    </div>
                </div>
                <!-- Logout -->
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <a class="d-flex align-items-center text-danger" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); this.closest('form').submit();">
                        <i class="fas fa-sign-out-alt me-3"></i><?php echo e(__('Cerrar Sesión')); ?>

                    </a>
                </form>
            </div>
        </div>
    </div>
</nav>

<!-- Estilos -->
<style>
    .navbar {
        position: relative;
        height: 65px;
        overflow: visible;
        padding-top: 0;
        padding-bottom: 0;
    }
        
    .navbar-brand {
        padding-top: 0.5rem;
        padding-bottom: 0.5rem;
        margin-right: auto;
        margin-left: auto;
    }

    .navbar-collapse {
        justify-content: flex-start;
    }
    .nav-link {
        color: #333;
        font-weight: 500;
        transition: color 0.3s ease;
        padding: 0.5rem 1rem;
    }

    .nav-link:hover, .nav-link.active {
        color: #007bff;
    }

    .navbar-nav {
        margin-top: 8px;
    }

    .navbar-nav.align-items-center {
        margin-top: 20px;
        margin-left: auto;
    }

    .dropdown-menu {
        border: none;
        box-shadow: 0 0.5rem 1rem rgba(0,0,0,.15);
    }

    .dropdown-item {
        color: #333;
        transition: background-color 0.3s ease;
    }

    .dropdown-item:hover {
        background-color: #f8f9fa;
    }

    #themeToggle, #themeToggleMobile {
        font-size: 1.2rem;
        color: #6c757d;
        transition: color 0.3s ease;
    }

    #themeToggle:hover, #themeToggleMobile:hover {
        color: #007bff;
    }

    .notifications-dropdown {
        width: 300px;
        max-height: 400px;
        overflow-y: auto;
    }

    .notifications-content .dropdown-item,
    .notifications-content-mobile .dropdown-item {
        white-space: normal;
    }

    .notification-icon {
        font-size: 1.2rem;
        line-height: 1;
    }

    #notification-count, #notification-count-mobile {
        top: 0px;
        right: -16px;
        font-size: 0.65rem;
        padding: 0.25em 0.4em;
        min-width: 1.5em;
        height: 1.5em;
        line-height: 1.1;
        border-radius: 50%;
    }
    

    @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.2); }
        100% { transform: scale(1); }
    }

    #notification-count:not(:empty), #notification-count-mobile:not(:empty) {
        animation: pulse 2s infinite;
    }

    /* Media queries ajustadas para el cambio a vista móvil en 1213px */
    @media (min-width: 1213px) {
        .navbar-expand-xl {
            flex-wrap: nowrap;
            justify-content: flex-start;
        }
        .navbar-expand-xl .navbar-toggler {
            display: none;
        }
        .navbar-expand-xl .navbar-collapse {
            display: flex !important;
            flex-basis: auto;
        }
        .offcanvas {
            display: none;
        }
    }

    @media (max-width: 1212.98px) {
        .navbar-expand-xl .navbar-collapse {
            display: none !important;
        }
        .navbar-expand-xl .navbar-toggler {
            display: block;
        }
        .navbar-brand {
            margin-left: 0;
        }
        .offcanvas {
            display: block;
        }
    }

    /* Ajustes adicionales para la vista móvil */
    @media (max-width: 1212.98px) {
        .navbar-nav {
            padding-top: 0.5rem;
        }
        .nav-item {
            padding: 0.25rem 0;
        }
        .navbar-nav .nav-link {
            padding: 0.5rem 1rem;
        }
        .navbar-brand img {
            height: 35px;
        }
    }

    @media (max-width: 575.98px) {
        .navbar-brand img {
            height: 30px;
        }
    }

    .logo-container {
        position: relative;
        margin-right: 20px;
        top: -5px;
    }

    .navbar-collapse {
        justify-content: flex-start;
        margin-left: 0;
    }

    /* Estilos para el offcanvas */
    .offcanvas {
        width: 250px;
    }

    .offcanvas-header {
        border-bottom: 1px solid #dee2e6;
    }

    .offcanvas-body .nav-link {
        padding: 0.75rem 1.25rem;
        color: #333;
    }

    .offcanvas-body .nav-link:hover, .offcanvas-body .nav-link.active {
        background-color: #f8f9fa;
        color: #007bff;
    }

    .offcanvas-body .navbar-nav {
        margin-top: 0;
    }
    /* Estilos para móvil */
    @media (max-width: 1212.98px) {
        .offcanvas {
            width: 280px;
        }

        .offcanvas-title {
            font-size: 1.25rem;
            font-weight: 600;
        }

        .offcanvas-body .nav-link {
            padding: 0.75rem 0;
            font-size: 1rem;
            color: #333;
            transition: all 0.3s ease;
        }

        .offcanvas-body .nav-link:hover,
        .offcanvas-body .nav-link.active {
            color: #007bff;
            background-color: rgba(0, 123, 255, 0.1);
            padding-left: 0.5rem;
        }

        .offcanvas-body .navbar-nav {
            margin-top: 0;
        }

        #adminSubmenu .nav-link {
            font-size: 0.9rem;
            padding: 0.5rem 0;
        }

        .form-check-input {
            cursor: pointer;
        }

        .badge {
            font-size: 0.75rem;
            padding: 0.25em 0.6em;
        }
    }

    /* Animación para el toggle del tema */
    .form-check-input {
        transition: background-position 0.15s ease-in-out;
    }
    /* Estilos para el panel de notificaciones */
    .notifications-panel {
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        background-color: #fff;
        height: 80vh;
        transform: translateY(100%);
        transition: transform 0.3s ease-out;
        z-index: 1050;
        display: flex;
        flex-direction: column;
        box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
    }

    .notifications-panel.active {
        transform: translateY(0);
    }

    .notifications-panel-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 1rem;
        border-bottom: 1px solid #e9ecef;
    }

    .notifications-panel-body {
        flex-grow: 1;
        overflow-y: auto;
        padding: 1rem;
    }

    .notifications-panel-footer {
        padding: 1rem;
        border-top: 1px solid #e9ecef;
    }

    .notifications-content-mobile .dropdown-item {
        border-bottom: 1px solid #e9ecef;
        padding: 1rem 0;
    }

    .notifications-content-mobile .dropdown-item:last-child {
        border-bottom: none;
    }

    /* Overlay para el fondo cuando el panel está abierto */
    .notifications-overlay {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: rgba(0,0,0,0.5);
        z-index: 1040;
        opacity: 0;
        visibility: hidden;
        transition: opacity 0.3s ease-out, visibility 0.3s ease-out;
    }

    .notifications-overlay.active {
        opacity: 1;
        visibility: visible;
    }
    
    
</style>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const NOTIFICATION_UPDATE_INTERVAL = 300000; // 5 minutos
    let lastNotificationCheck = 0;
    let notificationCount = 0;

    // Inicializar todos los dropdowns
    var dropdownElementList = [].slice.call(document.querySelectorAll('.dropdown-toggle'))
    dropdownElementList.forEach(function (dropdownToggleEl) {
        new bootstrap.Dropdown(dropdownToggleEl);
    });

    // Notifications
    function updateNotificationBadge(count) {
        const $countDesktop = $('#notification-count');
        const $countMobile = $('#notification-count-mobile');
        if (count > 0) {
            $countDesktop.text(count > 99 ? '99+' : count).show();
            $countMobile.text(count > 99 ? '99+' : count).show();
        } else {
            $countDesktop.hide();
            $countMobile.hide();
        }
    }

    function checkNewNotifications() {
        const now = Date.now();
        if (now - lastNotificationCheck < NOTIFICATION_UPDATE_INTERVAL) {
            return Promise.resolve(notificationCount);
        }

        return $.get('/check-notifications')
            .then(function(data) {
                lastNotificationCheck = now;
                notificationCount = data.count;
                updateNotificationBadge(notificationCount);
                return notificationCount;
            });
    }

    function getNotifications() {
        return $.get('/get-notifications')
            .then(function(notificationsHtml) {
                $('.notifications-content, .notifications-content-mobile').html(notificationsHtml);
            });
    }

    function updateNotifications() {
        checkNewNotifications()
            .then(function(count) {
                if (count > 0) {
                    return getNotifications();
                } else {
                    $('.notifications-content, .notifications-content-mobile').html('<li><a class="dropdown-item py-2" href="#">No hay notificaciones nuevas</a></li>');
                }
            });
    }

    updateNotifications();
    setInterval(updateNotifications, NOTIFICATION_UPDATE_INTERVAL);

    $(document).on('click', '.notifications-content .dropdown-item, .notifications-content-mobile .dropdown-item', function(e) {
        e.preventDefault();
        var notificationId = $(this).data('notification-id');
        var link = $(this).attr('href');

        $.ajax({
            url: '/notifications/' + notificationId + '/mark-as-read',
            type: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                if(response.success) {
                    window.location.href = link;
                }
            },
            error: function(xhr, status, error) {
                console.error('Error marking notification as read:', error);
            }
        });
    });

    // Panel de notificaciones para móvil
    const openPanelBtn = document.getElementById('openNotificationsPanel');
    const closeBtn = document.getElementById('closeNotificationsPanel');
    const panel = document.getElementById('notificationsPanel');
    const body = document.body;

    function openPanel() {
        panel.classList.add('active');
        body.insertAdjacentHTML('beforeend', '<div class="notifications-overlay"></div>');
        setTimeout(() => {
            document.querySelector('.notifications-overlay').classList.add('active');
        }, 10);
        updateNotifications();
    }

    function closePanel() {
        panel.classList.remove('active');
        const overlay = document.querySelector('.notifications-overlay');
        overlay.classList.remove('active');
        setTimeout(() => {
            overlay.remove();
        }, 300);
    }

    openPanelBtn.addEventListener('click', openPanel);
    closeBtn.addEventListener('click', closePanel);

    document.addEventListener('click', function(event) {
        if (event.target.classList.contains('notifications-overlay')) {
            closePanel();
        }
    });

    // Marcar todas las notificaciones como leídas
    function markAllAsRead() {
        $.ajax({
            url: '/mark-all-notifications-as-read',
            type: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                if(response.success) {
                    notificationCount = 0;
                    updateNotificationBadge(0);
                    $('.notifications-content, .notifications-content-mobile').html('<li><a class="dropdown-item py-2" href="#">No hay notificaciones nuevas</a></li>');
                    // Opcional: mostrar un mensaje de éxito
                    alert('Todas las notificaciones han sido marcadas como leídas');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error marking all notifications as read:', error);
                // Opcional: mostrar un mensaje de error
                alert('Hubo un error al marcar las notificaciones como leídas');
            }
        });
    }

    // Asignar la función markAllAsRead a los botones correspondientes
    $('#markAllAsReadDesktop, #markAllAsRead').click(markAllAsRead);
});
</script><?php /**PATH /home/inventariohidroo/public_html/resources/views/layouts/navigation.blade.php ENDPATH**/ ?>