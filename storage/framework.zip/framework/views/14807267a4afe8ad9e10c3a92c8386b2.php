

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-primary text-white">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-center">
                <h2 class="mb-3 mb-md-0 fs-4">
                    <i class="fas fa-tools me-2"></i> Mantenimientos
                    <?php if(request('filtro') === 'realizados'): ?>
                        <span class="badge bg-success ms-2">Realizados</span>
                    <?php elseif(request('filtro') === 'pendientes'): ?>
                        <span class="badge bg-warning ms-2">Pendientes</span>
                    <?php endif; ?>
                </h2>
                <div class="d-flex flex-wrap justify-content-center justify-content-md-end">
                    <?php if(request()->has('inventario_id')): ?>
                        <a href="<?php echo e(route('inventarios.show', request('inventario_id'))); ?>" class="btn btn-light btn-sm me-2 mb-2 mb-md-0">
                            <i class="fas fa-arrow-left me-1"></i> Volver al Inventario
                        </a>
                    <?php endif; ?>
                    <div class="btn-group mb-2 mb-md-0" role="group">
                        <a href="<?php echo e(route('mantenimientos.index')); ?>" class="btn btn-light btn-sm <?php echo e(!request('filtro') ? 'active' : ''); ?>">
                            <i class="fas fa-list me-1"></i> Todos
                        </a>
                        <a href="<?php echo e(route('mantenimientos.index', ['filtro' => 'realizados'])); ?>" class="btn btn-light btn-sm <?php echo e(request('filtro') === 'realizados' ? 'active' : ''); ?>">
                            <i class="fas fa-check me-1"></i> Realizados
                        </a>
                        <a href="<?php echo e(route('mantenimientos.index', ['filtro' => 'pendientes'])); ?>" class="btn btn-light btn-sm <?php echo e(request('filtro') === 'pendientes' ? 'active' : ''); ?>">
                            <i class="fas fa-clock me-1"></i> Pendientes
                        </a>
                    </div>
                    <?php if(auth()->user()->role->name === 'administrador' || auth()->user()->role->name === 'almacenista'): ?>
                        <a href="<?php echo e(route('mantenimientos.create')); ?>" class="btn btn-light btn-sm ms-md-2">
                            <i class="fas fa-plus me-1"></i> Nuevo Mantenimiento
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="card-body">
            <?php if($mantenimientos->isEmpty()): ?>
                <p class="text-muted fs-5 text-center">No hay mantenimientos registrados.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Elemento</th>
                                <th>Tipo</th>
                                <th>Fecha Programada</th>
                                <th>Estado</th>
                                <th>Responsable</th>
                                <th>Solicitado por</th>
                                <th>Periodicidad</th>
                                <th class="text-center">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $mantenimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mantenimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div class="d-flex flex-column">
                                            <span class="fw-bold"><?php echo e($mantenimiento->inventario->nombre); ?></span>
                                            <small class="text-muted"><?php echo e($mantenimiento->inventario->codigo_unico); ?></small>
                                        </div>
                                    </td>
                                    <td><?php echo e(ucfirst($mantenimiento->tipo)); ?></td>
                                    <td><?php echo e($mantenimiento->fecha_programada->format('d/m/Y')); ?></td>
                                    <td>
                                        <?php if($mantenimiento->fecha_realizado): ?>
                                            <span class="badge bg-success">Realizado</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning">Pendiente</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($mantenimiento->responsable ? $mantenimiento->responsable->nombre : 'No asignado'); ?></td>
                                    <td><?php echo e($mantenimiento->solicitadoPor->name); ?></td>
                                    <td><?php echo e(ucfirst($mantenimiento->periodicidad ?? 'N/A')); ?></td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <a href="<?php echo e(route('mantenimientos.show', $mantenimiento)); ?>" class="btn btn-outline-info btn-sm">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <?php if(auth()->user()->role->name === 'administrador'): ?>
                                                <a href="<?php echo e(route('mantenimientos.edit', $mantenimiento)); ?>" class="btn btn-outline-warning btn-sm">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="d-flex justify-content-center mt-4">
                    <?php echo e($mantenimientos->appends(request()->query())->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    @media (max-width: 767.98px) {
        .table-responsive {
            font-size: 0.875rem;
        }
        .table th, .table td {
            white-space: nowrap;
        }
        .btn-group .btn {
            padding: 0.25rem 0.5rem;
            font-size: 0.75rem;
        }
    }
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/inventariohidroo/public_html/resources/views/mantenimientos/index.blade.php ENDPATH**/ ?>