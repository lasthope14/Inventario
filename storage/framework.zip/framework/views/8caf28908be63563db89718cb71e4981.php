
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Header Fijo -->
    <div class="header-fixed">
        <div class="header-content bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center p-3">
                <h1 class="h3 mb-0">
                    <i class="fas fa-clipboard-list me-2"></i>Detalles del Elemento
                </h1>
                <div class="d-flex gap-2">
                    <?php if(auth()->user()->role->name === 'administrador'): ?>
                        <a href="<?php echo e(route('inventarios.edit', $inventario)); ?>" 
                           class="btn btn-outline-light">
                            <i class="fas fa-edit me-md-2"></i>
                            <span class="d-none d-md-inline">Editar</span>
                        </a>
                    <?php endif; ?>
                    <a href="<?php echo e(route('inventarios.index')); ?>" 
                       class="btn btn-light">
                        <i class="fas fa-arrow-left me-md-2"></i>
                        <span class="d-none d-md-inline">Volver</span>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Contenido Principal con padding-top para evitar que se oculte bajo el header fijo -->
    <div class="main-content">
    <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header bg-light">
                            <h5 class="card-title mb-0"><i class="fas fa-info-circle me-2"></i>Información Básica</h5>
                        </div>
                        <div class="card-body">
                            <dl class="row">
                                <dt class="col-sm-4">Código:</dt>
                                <dd class="col-sm-8"><?php echo e($inventario->codigo_unico); ?></dd>
                                <dt class="col-sm-4">Categoría:</dt>
                                <dd class="col-sm-8"><?php echo e($inventario->categoria->nombre); ?></dd>
                                <dt class="col-sm-4">Nombre:</dt>
                                <dd class="col-sm-8"><?php echo e($inventario->nombre); ?></dd>
                                <dt class="col-sm-4">Propietario:</dt>
                                <dd class="col-sm-8"><?php echo e($inventario->propietario); ?></dd>
                            </dl>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header bg-light">
                            <h5 class="card-title mb-0"><i class="fas fa-cog me-2"></i>Detalles Técnicos</h5>
                        </div>
                        <div class="card-body">
                            <dl class="row">
                                <dt class="col-sm-4">Modelo:</dt>
                                <dd class="col-sm-8"><?php echo e($inventario->modelo ?? 'N/A'); ?></dd>
                                <dt class="col-sm-4">Número de Serie:</dt>
                                <dd class="col-sm-8"><?php echo e($inventario->numero_serie ?? 'N/A'); ?></dd>
                                <dt class="col-sm-4">Marca:</dt>
                                <dd class="col-sm-8"><?php echo e($inventario->marca ?? 'N/A'); ?></dd>
                                <dt class="col-sm-4">Proveedor:</dt>
                                <dd class="col-sm-8"><?php echo e($inventario->proveedor->nombre); ?></dd>
                            </dl>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header bg-light">
                            <h5 class="card-title mb-0"><i class="fas fa-dollar-sign me-2"></i>Información Financiera</h5>
                        </div>
                        <div class="card-body">
                            <dl class="row">
                                <dt class="col-sm-4">Fecha de Compra:</dt>
                                <dd class="col-sm-8"><?php echo e($inventario->fecha_compra ? $inventario->fecha_compra->format('d/m/Y') : 'N/A'); ?></dd>
                                
                                <dt class="col-sm-4">Número de Factura:</dt>
                                <dd class="col-sm-8"><?php echo e($inventario->numero_factura ?? 'N/A'); ?></dd>
                                
                                <dt class="col-sm-4">Valor Unitario:</dt>
                                <dd class="col-sm-8">$<?php echo e(number_format($inventario->valor_unitario, 2)); ?></dd>
                                
                                <dt class="col-sm-4">Cantidad Total:</dt>
                                <dd class="col-sm-8"><?php echo e($inventario->cantidad_total); ?></dd>
                                
                                <dt class="col-sm-4">Valor Total:</dt>
                                <dd class="col-sm-8">$<?php echo e(number_format($inventario->valor_total, 2)); ?></dd>
                            </dl>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header bg-light">
                            <h5 class="card-title mb-0"><i class="fas fa-calendar-alt me-2"></i>Fechas Importantes</h5>
                        </div>
                        <div class="card-body">
                            <dl class="row">
                                <dt class="col-sm-4">Fecha de Baja:</dt>
                                <dd class="col-sm-8"><?php echo e($inventario->fecha_baja ? $inventario->fecha_baja->format('d/m/Y') : 'N/A'); ?></dd>
                                <dt class="col-sm-4">Fecha de Inspección:</dt>
                                <dd class="col-sm-8"><?php echo e($inventario->fecha_inspeccion ? $inventario->fecha_inspeccion->format('d/m/Y') : 'N/A'); ?></dd>
                            </dl>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header bg-light">
                    <h5 class="card-title mb-0"><i class="fas fa-map-marker-alt me-2"></i>Distribución por Ubicaciones</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <h6 class="fw-bold">Cantidad Total: <?php echo e($inventario->ubicaciones->sum('cantidad')); ?></h6>
                    </div>
                    <div class="row justify-content-center">
                        <?php $__currentLoopData = $inventario->ubicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ubicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($ubicacion->cantidad > 0): ?>
                                <div class="col-12 col-sm-6 col-md-4 col-lg-3 mb-3">
                                    <div class="card h-100">
                                        <div class="card-body d-flex flex-column justify-content-between">
                                            <div class="text-center mb-3">
                                                <i class="fas fa-building fa-2x text-primary mb-2"></i>
                                                <h6 class="card-title"><?php echo e($ubicacion->ubicacion->nombre); ?></h6>
                                            </div>
                                            <div class="text-center">
                                                <p class="card-text mb-2">
                                                    <i class="fas fa-boxes me-2 text-secondary"></i>
                                                    Cantidad: <?php echo e($ubicacion->cantidad); ?>

                                                </p>
                                                <span class="badge bg-<?php echo e($ubicacion->estado == 'disponible' ? 'success' : ($ubicacion->estado == 'en uso' ? 'primary' : ($ubicacion->estado == 'en mantenimiento' ? 'warning' : ($ubicacion->estado == 'robado' ? 'dark' : 'danger')))); ?>">
                                                    <i class="fas fa-<?php echo e($ubicacion->estado == 'disponible' ? 'check' : ($ubicacion->estado == 'en uso' ? 'hand-paper' : ($ubicacion->estado == 'en mantenimiento' ? 'tools' : ($ubicacion->estado == 'robado' ? 'exclamation-triangle' : 'ban')))); ?> me-1"></i>
                                                    <?php echo e(ucfirst($ubicacion->estado)); ?>

                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header bg-light">
                    <h5 class="card-title mb-0"><i class="fas fa-image me-2"></i>Imágenes</h5>
                </div>
                <div class="card-body">
                    <div class="row justify-content-center">
                        <div class="col-12 col-lg-6 mb-3">
                            <div class="text-center">
                                <h6 class="mb-3">Imagen Principal</h6>
                                <div style="max-width: 500px; max-height: 500px; margin: auto; border: 2px solid #ddd; border-radius: 10px; padding: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
                                    <?php if($inventario->imagen_principal): ?>
                                        <img src="<?php echo e(asset('storage/' . $inventario->imagen_principal)); ?>" 
                                             alt="Imagen principal" 
                                             style="max-width: 100%; max-height: 480px; width: auto; height: auto; cursor: zoom-in; border-radius: 5px;"
                                             onclick="openImageModal('<?php echo e(asset('storage/' . $inventario->imagen_principal)); ?>')">
                                    <?php else: ?>
                                        <div style="height: 480px; display: flex; align-items: center; justify-content: center;">
                                            <p class="text-muted">No hay imagen principal</p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-lg-6 mb-3">
                            <div class="text-center">
                                <h6 class="mb-3">Imagen Secundaria</h6>
                                <div style="max-width: 500px; max-height: 500px; margin: auto; border: 2px solid #ddd; border-radius: 10px; padding: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
                                    <?php if($inventario->imagen_secundaria): ?>
                                        <img src="<?php echo e(asset('storage/' . $inventario->imagen_secundaria)); ?>" 
                                             alt="Imagen secundaria" 
                                             style="max-width: 100%; max-height: 480px; width: auto; height: auto; cursor: zoom-in; border-radius: 5px;"
                                             onclick="openImageModal('<?php echo e(asset('storage/' . $inventario->imagen_secundaria)); ?>')">
                                    <?php else: ?>
                                        <div style="height: 480px; display: flex; align-items: center; justify-content: center;">
                                            <p class="text-muted">No hay imagen secundaria</p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header bg-light">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-comment-alt me-2"></i>Observaciones
                        <button class="btn btn-sm btn-primary float-end" id="toggleObservaciones">
                            <i class="fas fa-chevron-down"></i>
                        </button>
                    </h5>
                </div>
                <div class="card-body" id="observacionesContent" style="display: none;">
                    <?php if($inventario->observaciones): ?>
                        <div class="observaciones-container">
                            <?php $__currentLoopData = explode("\n", $inventario->observaciones); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $observacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(trim($observacion) !== ''): ?>
                                    <p class="observacion-item">
                                        <i class="fas fa-circle me-2 text-primary"></i>
                                        <?php echo e($observacion); ?>

                                    </p>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">No hay observaciones registradas.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header bg-light">
                    <h5 class="card-title mb-0"><i class="fas fa-history me-2"></i>Historial y Documentación</h5>
                </div>
                <div class="card-body">
                    <ul class="nav nav-tabs nav-fill flex-column flex-sm-row" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active w-100" id="movimientos-tab" data-bs-toggle="tab" data-bs-target="#movimientos" type="button" role="tab" aria-controls="movimientos" aria-selected="true">Movimientos</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link w-100" id="mantenimientos-tab" data-bs-toggle="tab" data-bs-target="#mantenimientos" type="button" role="tab" aria-controls="mantenimientos" aria-selected="false">Mantenimientos</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link w-100" id="documentos-tab" data-bs-toggle="tab" data-bs-target="#documentos" type="button" role="tab" aria-controls="documentos" aria-selected="false">Documentos</button>
                        </li>
                    </ul>
                    <div class="tab-content mt-3" id="myTabContent">
                        <div class="tab-pane fade show active" id="movimientos" role="tabpanel" aria-labelledby="movimientos-tab">
                            <?php if(auth()->user()->role->name === 'administrador' || auth()->user()->role->name === 'almacenista'): ?>
                                <a href="<?php echo e(route('movimientos.create', ['inventario_id' => $inventario->id])); ?>" class="btn btn-primary mb-3">
                                    <i class="fas fa-plus me-2"></i>Registrar Movimiento
                                </a>
                            <?php endif; ?>
                            <?php if($inventario->movimientos->isEmpty()): ?>
                                <div class="alert alert-info" role="alert">
                                    <i class="fas fa-info-circle me-2"></i>No hay movimientos registrados para este elemento.
                                </div>
                            <?php else: ?>
                                <div class="table-responsive">
                                    <table class="table table-hover table-striped">
                                        <thead class="table-light">
                                            <tr>
                                                <th class="text-center">Fecha</th>
                                                <th class="text-center">Origen</th>
                                                <th class="text-center">Destino</th>
                                                <th class="text-center">Realizado por</th>
                                                <th class="text-center">Acciones</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $inventario->movimientos->sortByDesc('fecha_movimiento')->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="text-center"><?php echo e($movimiento->fecha_movimiento->format('d/m/Y H:i')); ?></td>
                                                    <td class="text-center"><?php echo e($movimiento->ubicacionOrigen->nombre ?? 'N/A'); ?></td>
                                                    <td class="text-center"><?php echo e($movimiento->ubicacionDestino->nombre ?? 'N/A'); ?></td>
                                                    <td class="text-center"><?php echo e($movimiento->realizadoPor->name ?? 'N/A'); ?></td>
                                                    <td class="text-center">
                                                        <a href="<?php echo e(route('movimientos.show', $movimiento)); ?>" class="btn btn-sm btn-outline-info">
                                                            <i class="fas fa-eye"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <a href="<?php echo e(route('movimientos.index', ['inventario_id' => $inventario->id])); ?>" class="btn btn-link">Ver todos los movimientos</a>
                            <?php endif; ?>
                        </div>
                        <div class="tab-pane fade" id="mantenimientos" role="tabpanel" aria-labelledby="mantenimientos-tab">
                            <?php if(auth()->user()->role->name === 'administrador' || auth()->user()->role->name === 'almacenista'): ?>
                                <a href="<?php echo e(route('mantenimientos.create', ['inventario_id' => $inventario->id])); ?>" class="btn btn-primary mb-3">
                                    <i class="fas fa-plus me-2"></i>Programar Mantenimiento
                                </a>
                            <?php endif; ?>
                            <?php if($inventario->mantenimientos->isEmpty()): ?>
                                <div class="alert alert-info" role="alert">
                                    <i class="fas fa-info-circle me-2"></i>No hay mantenimientos programados para este elemento.
                                </div>
                            <?php else: ?>
                                <div class="table-responsive">
                                    <table class="table table-hover table-striped">
                                        <thead class="table-light">
                                            <tr>
                                                <th class="text-center">Tipo</th>
                                                <th class="text-center">Descripción</th>
                                                <th class="text-center">Fecha Programada</th>
                                                <th class="text-center">Estado</th>
                                                <th class="text-center">Pospuesto</th>
                                                <th class="text-center">Acciones</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $inventario->mantenimientos->sortBy('fecha_programada')->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mantenimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="text-center"><?php echo e(ucfirst($mantenimiento->tipo)); ?></td>
                                                    <td class="text-center"><?php echo e(Str::limit($mantenimiento->descripcion, 50)); ?></td>
                                                    <td class="text-center"><?php echo e($mantenimiento->fecha_programada->format('d/m/Y')); ?></td>
                                                    <td class="text-center">
                                                        <?php if($mantenimiento->fecha_realizado): ?>
                                                            <span class="badge bg-success">Realizado</span>
                                                        <?php elseif($mantenimiento->tipo === 'correctivo'): ?>
                                                            <span class="badge bg-danger">Urgente</span
                                                            <?php else: ?>
                                                            <span class="badge bg-warning">Pendiente</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="text-center">
                                                        <?php if($mantenimiento->veces_pospuesto > 0): ?>
                                                            <span class="badge bg-secondary"><?php echo e($mantenimiento->veces_pospuesto); ?> <?php echo e($mantenimiento->veces_pospuesto == 1 ? 'vez' : 'veces'); ?></span>
                                                        <?php else: ?>
                                                            -
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="text-center">
                                                        <a href="<?php echo e(route('mantenimientos.show', $mantenimiento)); ?>" class="btn btn-sm btn-outline-info">
                                                            <i class="fas fa-eye"></i>
                                                        </a>
                                                        <?php if(!$mantenimiento->fecha_realizado && (auth()->user()->role->name === 'administrador')): ?>
                                                            <button onclick="marcarRealizado(<?php echo e($mantenimiento->id); ?>)" class="btn btn-sm btn-outline-success">
                                                                <i class="fas fa-check"></i>
                                                            </button>
                                                            <button onclick="posponerMantenimiento(<?php echo e($mantenimiento->id); ?>)" class="btn btn-sm btn-outline-warning">
                                                                <i class="fas fa-clock"></i>
                                                            </button>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <a href="<?php echo e(route('mantenimientos.index', ['inventario_id' => $inventario->id])); ?>" class="btn btn-link">Ver todos los mantenimientos</a>
                            <?php endif; ?>
                        </div>
                        <div class="tab-pane fade" id="documentos" role="tabpanel" aria-labelledby="documentos-tab">
                            <?php if(auth()->user()->role->name === 'administrador' || auth()->user()->role->name === 'almacenista'): ?>
                                <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#uploadDocumentoModal">
                                    <i class="fas fa-plus me-2"></i>Añadir Documento
                                </button>
                            <?php endif; ?>
                            <?php if($inventario->documentos->isEmpty()): ?>
                                <div class="alert alert-info" role="alert">
                                    <i class="fas fa-info-circle me-2"></i>No hay documentos asociados a este elemento.
                                </div>
                            <?php else: ?>
                                <div class="table-responsive">
                                    <table class="table table-hover table-striped">
                                        <thead class="table-light">
                                            <tr>
                                                <th class="text-center">Nombre del Documento</th>
                                                <th class="text-center">Fecha de Subida</th>
                                                <th class="text-center">Acciones</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $inventario->documentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="text-center"><?php echo e($documento->nombre); ?></td>
                                                    <td class="text-center"><?php echo e($documento->created_at->format('d/m/Y H:i')); ?></td>
                                                    <td class="text-center">
                                                        <a href="<?php echo e(route('documentos.download', $documento)); ?>" class="btn btn-sm btn-outline-primary">
                                                            <i class="fas fa-download"></i>
                                                        </a>
                                                        <?php if(auth()->user()->role->name === 'administrador'): ?>
                                                            <form action="<?php echo e(route('documentos.destroy', $documento)); ?>" method="POST" class="d-inline">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('¿Estás seguro de que quieres eliminar este documento?')">
                                                                    <i class="fas fa-trash"></i>
                                                                </button>
                                                            </form>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal para ver imágenes en grande -->
<div class="modal fade" id="imageModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content">
            <div class="modal-body p-0">
                <img src="" class="img-fluid" id="modalImage" alt="Imagen ampliada">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal para subir documentos -->
<div class="modal fade" id="uploadDocumentoModal" tabindex="-1" aria-labelledby="uploadDocumentoModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="uploadDocumentoModalLabel">Subir Nuevo Documento</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('documentos.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <input type="hidden" name="inventario_id" value="<?php echo e($inventario->id); ?>">
                    <div class="mb-3">
                        <label for="nombre" class="form-label">Nombre del Documento</label>
                        <input type="text" class="form-control" id="nombre" name="nombre" required>
                    </div>
                    <div class="mb-3">
                        <label for="archivo" class="form-label">Archivo</label>
                        <input type="file" class="form-control" id="archivo" name="archivo" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <button type="submit" class="btn btn-primary">Subir Documento</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<style>
    /* Estilos Base */
    body {
        background-color: #f8f9fa;
    }
    
    .card {
        border-radius: 15px;
        box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
    }
    
    .card-header {
        border-top-left-radius: 15px;
        border-top-right-radius: 15px;
    }
    
    .form-control, .form-select {
        border-radius: 10px;
    }
    
    /* Header y Botones */
    .header-fixed {
        position: sticky;
        top: 65px;
        left: 0;
        right: 0;
        z-index: 1040;
        margin-bottom: 1.5rem;
        transition: box-shadow 0.3s ease;
    }

    .header-fixed.scrolled {
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }

    .header-content {
        background-color: #0d6efd;
        padding: 1rem;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .header-content h1 {
        font-size: 1.5rem;
        margin: 0;
        color: white;
    }

    .header-content .btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 0.5rem 1rem;
        border-radius: 0.375rem;
        font-weight: 500;
        transition: all 0.2s ease-in-out;
    }

    .header-content .btn-light {
        background-color: #fff;
        border-color: #fff;
        color: #0d6efd;
    }

    .header-content .btn-light:hover {
        background-color: #f8f9fa;
        border-color: #f8f9fa;
    }

    /* Observaciones */
    .observaciones-container {
        max-height: 300px;
        overflow-y: auto;
        padding-right: 10px;
    }
    
    .observacion-item {
        margin-bottom: 10px;
        padding: 10px;
        background-color: #f8f9fa;
        border-radius: 5px;
        border-left: 3px solid #0d6efd;
    }
    
    .observacion-item:last-child {
        margin-bottom: 0;
    }

    #toggleObservaciones:focus {
        box-shadow: none;
    }

    /* Badges y Estados */
    .badge {
        font-size: 0.9em;
        padding: 0.5em 0.7em;
        border-radius: 0.5rem;
    }

    /* Tabs */
    .nav-tabs {
        border-bottom: none;
        display: flex;
        gap: 0.5rem;
    }

    .nav-tabs .nav-link {
        border: 1px solid #dee2e6;
        border-radius: 0.5rem;
        padding: 0.75rem 1.25rem;
        font-weight: 500;
        color: #495057;
        background-color: #f8f9fa;
        transition: all 0.2s ease-in-out;
    }

    .nav-tabs .nav-link.active {
        background-color: #0d6efd;
        color: #ffffff;
        border-color: #0d6efd;
    }

    /* Tablas */
    .table-responsive {
        border-radius: 0.5rem;
        overflow: hidden;
    }

    .table {
        margin-bottom: 0;
    }

    .table th {
        background-color: #f8f9fa;
        font-weight: 600;
    }

    /* Modal de Imágenes */
    #imageModal .modal-dialog {
        max-width: 90%;
        margin: 1.75rem auto;
    }

    #imageModal .modal-content {
        background-color: transparent;
        border: none;
    }

    #imageModal .modal-body {
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 80vh;
    }

    #imageModal img {
        max-width: 100%;
        max-height: 80vh;
        object-fit: contain;
    }

    /* Responsive Design */
    @media (max-width: 767px) {
        .header-fixed {
            top: 56px;
        }

        .header-content {
            padding: 0.75rem;
        }

        .header-content h1 {
            font-size: 1.1rem;
        }

        .header-content .btn {
            padding: 0.375rem 0.75rem;
            font-size: 0.875rem;
        }

        .header-content .btn i {
            margin-right: 0 !important;
            font-size: 1rem;
        }

        .header-content .btn span {
            display: none;
        }

        .nav-tabs {
            flex-direction: column;
        }

        .nav-tabs .nav-link {
            width: 100%;
            text-align: center;
            margin-bottom: 0.5rem;
        }

        .table td, .table th {
            padding: 0.5rem;
            font-size: 0.875rem;
        }

        .d-flex.gap-2 {
            gap: 0.375rem !important;
        }
    }

    @media (min-width: 768px) {
        .nav-tabs {
            flex-direction: row;
        }

        .nav-tabs .nav-item {
            flex: 1;
        }

        .header-content .btn span {
            display: inline;
        }
    }

    /* Utilidades */
    .cursor-pointer {
        cursor: pointer;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Funciones de imágenes
    window.openImageModal = function(src) {
        const modalImage = document.getElementById('modalImage');
        if (modalImage) {
            modalImage.src = src;
            const modal = new bootstrap.Modal(document.getElementById('imageModal'));
            modal.show();
        }
    }

    // Funciones de mantenimiento
    window.marcarRealizado = function(mantenimientoId) {
        if (confirm('¿Estás seguro de que quieres marcar este mantenimiento como realizado?')) {
            fetch(`/mantenimientos/${mantenimientoId}/marcar-realizado`, {
                method: 'PATCH',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    location.reload();
                } else {
                    alert('Hubo un error al marcar el mantenimiento como realizado.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Hubo un error al procesar la solicitud.');
            });
        }
    }

    window.posponerMantenimiento = function(mantenimientoId) {
        if (confirm('¿Estás seguro de que quieres posponer este mantenimiento?')) {
            fetch(`/mantenimientos/${mantenimientoId}/posponer`, {
                method: 'PATCH',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    location.reload();
                } else {
                    alert('Hubo un error al posponer el mantenimiento.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Hubo un error al procesar la solicitud.');
            });
        }
    }

    // Manejador de observaciones
    const toggleBtn = document.getElementById('toggleObservaciones');
    const observacionesContent = document.getElementById('observacionesContent');
    
    if (toggleBtn && observacionesContent) {
        toggleBtn.addEventListener('click', function() {
            if (observacionesContent.style.display === 'none') {
                observacionesContent.style.display = 'block';
                toggleBtn.innerHTML = '<i class="fas fa-chevron-up"></i>';
            } else {
                observacionesContent.style.display = 'none';
                toggleBtn.innerHTML = '<i class="fas fa-chevron-down"></i>';
            }
        });
    }

    // Manejador de scroll
    const header = document.querySelector('.header-fixed');
    if (header) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 0) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/inventariohidroo/public_html/resources/views/inventarios/show.blade.php ENDPATH**/ ?>