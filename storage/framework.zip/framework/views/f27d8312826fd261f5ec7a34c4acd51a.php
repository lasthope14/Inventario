

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-primary text-white">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-center">
                <h2 class="mb-3 mb-md-0 fs-4">Hoja de Ruta del Movimiento</h2>
                <div class="d-flex flex-wrap justify-content-center button-group">
                    <?php if(auth()->user()->role->name === 'administrador'): ?>
                        <a href="<?php echo e(route('movimientos.edit', $movimiento)); ?>" class="btn btn-light btn-action">
                            <i class="fas fa-edit"></i>
                            <span class="d-none d-md-inline ms-2">Editar</span>
                        </a>
                        <form action="<?php echo e(route('movimientos.destroy', $movimiento)); ?>" method="POST" class="d-inline" id="deleteForm">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-action" id="deleteButton" onclick="return confirmDelete(event)">
                                <i class="fas fa-trash"></i>
                                <span class="d-none d-md-inline ms-2">Eliminar</span>
                            </button>
                        </form>
                    <?php endif; ?>
                    <a href="<?php echo e(route('inventarios.show', $movimiento->inventario)); ?>" class="btn btn-light btn-action">
                        <i class="fas fa-arrow-left"></i>
                        <span class="d-none d-md-inline ms-2">Volver</span>
                    </a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4">
                    <h5 class="border-bottom pb-2 mb-3">Información del Elemento</h5>
                    <dl class="row">
                        <dt class="col-sm-4">Nombre:</dt>
                        <dd class="col-sm-8"><?php echo e($movimiento->inventario->nombre); ?></dd>
                        
                        <dt class="col-sm-4">Código:</dt>
                        <dd class="col-sm-8"><?php echo e($movimiento->inventario->codigo_unico); ?></dd>
                        
                        <dt class="col-sm-4">Categoría:</dt>
                        <dd class="col-sm-8"><?php echo e($movimiento->inventario->categoria->nombre); ?></dd>
                        
                        <dt class="col-sm-4">Cantidad Total:</dt>
                        <dd class="col-sm-8"><?php echo e($movimiento->inventario->cantidadTotal); ?></dd>
                        
                        <dt class="col-sm-4">Cantidad Movida:</dt>
                        <dd class="col-sm-8"><?php echo e($movimiento->cantidad); ?></dd>
                    </dl>
                    <div class="row mt-3">
                        <div class="col-md-6 mb-3">
                            <h6><i class="fas fa-image me-2"></i> Imagen Principal</h6>
                            <div class="image-container" style="height: 150px; overflow: hidden;">
                                <?php if($movimiento->inventario->imagen_principal): ?>
                                    <img src="<?php echo e(asset('storage/' . $movimiento->inventario->imagen_principal)); ?>" 
                                         class="img-fluid rounded cursor-pointer" 
                                         alt="Imagen principal" 
                                         onclick="openImageModal(this.src)" 
                                         style="object-fit: cover; width: 100%; height: 100%;">
                                <?php else: ?>
                                    <div class="d-flex justify-content-center align-items-center h-100 bg-light rounded">
                                        <span class="text-muted">Sin imagen principal</span>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <h6><i class="fas fa-images me-2"></i> Imagen Secundaria</h6>
                            <div class="image-container" style="height: 150px; overflow: hidden;">
                                <?php if($movimiento->inventario->imagen_secundaria): ?>
                                    <img src="<?php echo e(asset('storage/' . $movimiento->inventario->imagen_secundaria)); ?>" 
                                         class="img-fluid rounded cursor-pointer" 
                                         alt="Imagen secundaria" 
                                         onclick="openImageModal(this.src)" 
                                         style="object-fit: cover; width: 100%; height: 100%;">
                                <?php else: ?>
                                    <div class="d-flex justify-content-center align-items-center h-100 bg-light rounded">
                                        <span class="text-muted">Sin imagen secundaria</span>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <h5 class="border-bottom pb-2 mb-3">Detalles del Movimiento</h5>
                    <div class="row">
                        <div class="col-md-5">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item">
                                    <h6 class="mb-1">Origen</h6>
                                    <p class="mb-0"><strong>Ubicación:</strong> <?php echo e($movimiento->ubicacionOrigen->nombre ?? 'N/A'); ?></p>
                                    <p class="mb-0"><strong>Empleado:</strong> <?php echo e($movimiento->usuarioOrigen->nombre); ?> <?php echo e($movimiento->usuarioOrigen->cargo ? '- ' . $movimiento->usuarioOrigen->cargo : ''); ?></p>
                                </li>
                                <li class="list-group-item">
                                    <h6 class="mb-1">Movimiento</h6>
                                    <p class="mb-0"><strong>Fecha:</strong> <?php echo e($movimiento->fecha_movimiento->format('d/m/Y H:i')); ?></p>
                                    <p class="mb-0"><strong>Motivo:</strong> <?php echo e($movimiento->motivo ?? 'No especificado'); ?></p>
                                    <p class="mb-0"><strong>Realizado por:</strong> <?php echo e($movimiento->realizadoPor->name ?? 'N/A'); ?></p>
                                    <p class="mb-0"><strong>Cantidad movida:</strong> <?php echo e($movimiento->cantidad); ?></p>
                                </li>
                                <li class="list-group-item">
                                    <h6 class="mb-1">Destino</h6>
                                    <p class="mb-0"><strong>Ubicación:</strong> <?php echo e($movimiento->ubicacionDestino->nombre ?? 'N/A'); ?></p>
                                    <p class="mb-0"><strong>Empleado:</strong> <?php echo e($movimiento->usuarioDestino->nombre); ?> <?php echo e($movimiento->usuarioDestino->cargo ? '- ' . $movimiento->usuarioDestino->cargo : ''); ?></p>
                                </li>
                            </ul>
                        </div>
                        <div class="col-md-7 d-flex align-items-center justify-content-center">
                            <lottie-player 
                                src="https://lottie.host/ab409af5-cfce-40c1-9f51-f54ce30b967e/ove6TdscIe.json"
                                background="transparent"
                                speed="1"
                                style="width: 300px; height: 300px;"
                                loop
                                autoplay>
                            </lottie-player>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm h-100">
                <div class="card-body">
                    <h5 class="card-title mb-4">Resumen de Movimientos</h5>
                    <div class="d-flex align-items-center mb-3">
                        <div class="flex-shrink-0">
                            <i class="fas fa-exchange-alt fa-2x text-primary"></i>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h6 class="mb-0">Total Movimientos</h6>
                            <p class="mb-0 fs-4"><?php echo e($estadisticas['total_movimientos']); ?></p>
                        </div>
                    </div>
                    <div class="d-flex align-items-center mb-3">
                        <div class="flex-shrink-0">
                            <i class="fas fa-calendar-alt fa-2x text-info"></i>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h6 class="mb-0">Último Movimiento</h6>
                            <p class="mb-0"><?php echo e($estadisticas['ultimo_movimiento']); ?></p>
                        </div>
                    </div>
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <i class="fas fa-map-marker-alt fa-2x text-success"></i>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h6 class="mb-0">Ubicación Actual</h6>
                            <p class="mb-0"><?php echo e($estadisticas['ubicacion_actual']); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0">Movimientos por Mes</h5>
                </div>
                <div class="card-body">
                    <canvas id="movimientosChart"></canvas>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0">Ubicaciones más Frecuentes</h5>
                </div>
                <div class="card-body">
                    <canvas id="ubicacionesChart"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal para ver imágenes en grande -->
<div class="modal fade" id="imageModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-body p-0">
                <img src="" class="img-fluid w-100" id="modalImage" alt="Imagen ampliada">
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<style>
    .cursor-pointer {
        cursor: pointer;
    }
    .img-thumbnail {
        transition: transform 0.2s;
    }
    .img-thumbnail:hover {
        transform: scale(1.05);
    }
    .image-container img {
        transition: transform 0.3s ease;
    }
    .image-container img:hover {
        transform: scale(1.05);
    }
    
    .button-group {
        display: flex;
        gap: 10px;
    }
    
    .btn-action {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 40px;
        height: 40px;
        padding: 0;
        border-radius: 50%;
    }

    /* Estilos para el modal de imagen */
    .modal-dialog-centered {
        display: flex;
        align-items: center;
        min-height: calc(100% - 1rem);
    }

    .modal-content {
        width: 100%;
    }

    /* Estilos para Lottie Player */
    lottie-player {
        max-width: 100%;
        height: auto;
        margin: 0 auto;
    }

    /* Estilos para el spinner y botón deshabilitado */
    .spinner-border-sm {
        width: 1rem;
        height: 1rem;
        border-width: 0.2em;
        margin-right: 0.5rem;
    }

    .btn:disabled {
        cursor: not-allowed;
        opacity: 0.65;
    }

    .submitting {
        pointer-events: none;
    }

    #deleteButton:disabled {
        background-color: #dc3545;
        border-color: #dc3545;
    }
    @media (max-width: 768px) {
        .btn-action {
            width: auto;
            height: auto;
            border-radius: 0.25rem;
            padding: 0.375rem 0.75rem;
        }

        lottie-player {
            width: 200px !important;
            height: 200px !important;
        }
    }

    .timeline {
        position: relative;
        padding: 20px 0;
    }

    .timeline::before {
        content: '';
        background: #000;
        width: 2px;
        height: 100%;
        position: absolute;
        left: 18px;
        top: 0;
    }

    .timeline-item {
        margin-bottom: 30px;
        position: relative;
    }

    .timeline-icon {
        background: #fff;
        border: 2px solid #000;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        position: absolute;
        left: 0;
        top: 0;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .timeline-content {
        margin-left: 60px;
        background: #f8f9fa;
        padding: 15px;
        border-radius: 4px;
    }
    
    /* Estilos para modo oscuro */
    @media (prefers-color-scheme: dark) {
        body {
            background-color: #121212;
            color: #e0e0e0;
        }
        .card {
            background-color: #1e1e1e;
        }
        .card-header {
            background-color: #2c2c2c !important;
        }
        .list-group-item {
            background-color: #1e1e1e;
            color: #e0e0e0;
        }
        .modal-content {
            background-color: #1e1e1e;
            color: #e0e0e0;
        }
        .modal-header {
            border-bottom: 1px solid #333;
        }
        .modal-header .btn-close {
            filter: invert(1);
        }
        .timeline::before {
            background: #fff;
        }
        .timeline-icon {
            background: #1e1e1e;
            border-color: #fff;
        }
        .timeline-content {
            background: #2c2c2c;
        }
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://unpkg.com/@lottiefiles/lottie-player@2.0.8/dist/lottie-player.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Función para confirmar y manejar la eliminación
    window.confirmDelete = function(event) {
        event.preventDefault();
        
        const form = document.getElementById('deleteForm');
        const deleteButton = document.getElementById('deleteButton');
        
        // Si ya se está procesando la eliminación, evitar múltiples envíos
        if (form.getAttribute('data-submitting')) {
            return false;
        }

        // Confirmar la eliminación
        if (confirm('¿Estás seguro de que quieres eliminar este movimiento?')) {
            // Deshabilitar el botón y marcar el formulario como en proceso
            deleteButton.disabled = true;
            form.setAttribute('data-submitting', 'true');
            form.classList.add('submitting');
            
            // Cambiar el contenido del botón para mostrar el spinner
            deleteButton.innerHTML = `
                <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                <span class="d-none d-md-inline ms-2">Eliminando...</span>
            `;
            
            // Enviar el formulario
            form.submit();
        }
        
        return false;
    };

    // Función para abrir el modal de imagen
    window.openImageModal = function(src) {
        document.getElementById('modalImage').src = src;
        var modal = new bootstrap.Modal(document.getElementById('imageModal'));
        modal.show();
    }

    // Cerrar el modal al hacer clic fuera de la imagen
    document.getElementById('imageModal').addEventListener('click', function(event) {
        if (event.target === this) {
            bootstrap.Modal.getInstance(this).hide();
        }
    });

    // Gráfico de movimientos por mes
    var ctxMovimientos = document.getElementById('movimientosChart').getContext('2d');
    var movimientosChart = new Chart(ctxMovimientos, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($estadisticas['meses']); ?>,
            datasets: [{
                label: 'Movimientos',
                data: <?php echo json_encode($estadisticas['movimientos_por_mes']); ?>,
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });

    // Gráfico de ubicaciones más frecuentes
    var ctxUbicaciones = document.getElementById('ubicacionesChart').getContext('2d');
    var ubicacionesChart = new Chart(ctxUbicaciones, {
        type: 'doughnut',
        data: {
            labels: <?php echo json_encode($estadisticas['ubicaciones']); ?>,
            datasets: [{
                data: <?php echo json_encode($estadisticas['frecuencia_ubicaciones']); ?>,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.8)',
                    'rgba(54, 162, 235, 0.8)',
                    'rgba(255, 206, 86, 0.8)',
                    'rgba(75, 192, 192, 0.8)',
                    'rgba(153, 102, 255, 0.8)'
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                }
            }
        }
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/inventariohidroo/public_html/resources/views/movimientos/show.blade.php ENDPATH**/ ?>