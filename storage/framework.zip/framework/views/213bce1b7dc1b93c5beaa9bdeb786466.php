<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?> - Perfil</title>
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/favicon.ico')); ?>">
    
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
    /* Estilos Base */
    body {
        font-family: 'Poppins', sans-serif;
        background-color: #f0f4f8;
        -webkit-overflow-scrolling: touch;
    }

    /* Contenedor Principal */
    .profile-container {
        max-width: 1200px;
        margin: 2rem auto;
        padding: 0 1rem;
    }

    /* Navbar */
    .navbar {
        background-color: #fff;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        padding: 1rem 0;
        margin-bottom: 2rem;
    }

    .navbar-brand img {
        height: 40px;
    }

    /* Header del Perfil */
    .profile-header {
        background: #fff;
        border-radius: 15px;
        padding: 2rem;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        margin-bottom: 2rem;
    }

    .avatar-circle {
        width: 100px;
        height: 100px;
        background-color: #0056b3;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 2.5rem;
        font-weight: bold;
        margin-bottom: 1rem;
        transition: all 0.3s ease;
    }

    /* Tarjetas de Perfil */
    .profile-card {
        background: #fff;
        border-radius: 15px;
        padding: 1.5rem;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        margin-bottom: 1.5rem;
        transition: all 0.3s ease;
    }

    .profile-card h3 {
        color: #2d3748;
        font-size: 1.25rem;
        font-weight: 600;
        margin-bottom: 1.5rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    /* Formularios */
    .form-control {
        border-radius: 8px;
        padding: 0.75rem;
        border: 1px solid #e2e8f0;
        transition: all 0.3s ease;
    }

    .form-control:focus {
        border-color: #0056b3;
        box-shadow: 0 0 0 0.2rem rgba(0,86,179,0.25);
    }

    /* Botones */
    .btn-custom {
        padding: 0.75rem 1.5rem;
        border-radius: 8px;
        font-weight: 500;
        transition: all 0.3s ease;
    }

    .btn-primary {
        background-color: #0056b3;
        border: none;
    }

    .btn-primary:hover {
        background-color: #004494;
        transform: translateY(-1px);
    }

    .btn-danger {
        background-color: #dc3545;
        border: none;
    }

    .btn-danger:hover {
        background-color: #bb2d3b;
        transform: translateY(-1px);
    }

    /* Badges y Zonas Especiales */
    .status-badge {
        background-color: #e2e8f0;
        padding: 0.5rem 1rem;
        border-radius: 20px;
        font-size: 0.875rem;
        color: #4a5568;
    }

    .danger-zone {
        border: 1px solid #dc3545;
        border-radius: 15px;
        padding: 1.5rem;
        background-color: #fff5f5;
    }

    /* Modal Styles */
    .modal-content {
        border-radius: 15px;
        border: none;
    }

    .modal-header {
        border-bottom: 1px solid #e2e8f0;
    }

    .modal-footer {
        border-top: 1px solid #e2e8f0;
    }

    /* Responsive Breakpoints */
    @media (max-width: 991px) {
        .navbar {
            padding: 0.5rem 0;
        }

        .navbar-brand img {
            height: 35px;
        }

        .btn-outline-primary {
            padding: 0.5rem 1rem;
            font-size: 0.9rem;
        }

        .profile-container {
            margin: 1rem auto;
            padding: 0 0.5rem;
        }

        .profile-header {
            padding: 1rem;
            margin-bottom: 1rem;
        }

        .avatar-circle {
            width: 70px;
            height: 70px;
            font-size: 1.8rem;
        }
    }

    @media (max-width: 768px) {
        html {
            scroll-padding-top: 70px;
        }

        .profile-card {
            padding: 1rem;
        }

        .profile-card h3 {
            font-size: 1.1rem;
            margin-bottom: 1rem;
        }

        .form-control {
            padding: 0.5rem;
            font-size: 0.9rem;
            min-height: 44px;
        }

        .btn-custom {
            width: 100%;
            min-height: 44px;
            padding: 0.6rem 1rem;
            font-size: 0.9rem;
        }

        .danger-zone {
            padding: 1rem;
        }
    }

    @media (max-width: 576px) {
        .container {
            padding-left: 15px;
            padding-right: 15px;
        }

        .profile-header .row {
            flex-direction: column;
        }

        .profile-header .col-md-6 {
            width: 100%;
            text-align: center;
        }

        .profile-header .col-md-6.d-flex {
            flex-direction: column;
            align-items: center;
        }

        .avatar-circle {
            width: 60px;
            height: 60px;
            font-size: 1.5rem;
            margin-bottom: 1rem;
        }

        .ms-4 {
            margin-left: 0 !important;
            text-align: center;
        }

        .status-badge {
            margin-top: 1rem;
            display: block;
            text-align: center;
        }

        .form-label {
            font-size: 0.9rem;
        }

        small.text-muted {
            font-size: 0.8rem;
        }

        /* Modal en móviles */
        .modal-dialog {
            margin: 0.5rem;
        }

        .modal-content {
            padding: 0.5rem;
        }

        .modal-footer {
            flex-direction: column;
        }

        .modal-footer button {
            width: 100%;
            margin: 0.25rem 0 !important;
        }
    }

    /* Transiciones y Animaciones */
    .profile-card, 
    .btn-custom, 
    .form-control, 
    .avatar-circle {
        transition: all 0.3s ease;
    }
</style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('dashboard')); ?>">
                <img src="<?php echo e(asset('assets/logo.png')); ?>" alt="Logo">
            </a>
            <div class="d-flex align-items-center">
                <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-outline-primary me-2">
                    <i class="fas fa-arrow-left me-2"></i>Volver al Dashboard
                </a>
            </div>
        </div>
    </nav>

    <div class="profile-container">
        <!-- Header -->
        <div class="profile-header">
            <div class="row align-items-center">
                <div class="col-md-6 d-flex align-items-center">
                    <div class="avatar-circle">
                        <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

                    </div>
                    <div class="ms-4">
                        <h1 class="h3 mb-1"><?php echo e($user->name); ?></h1>
                        <p class="text-muted mb-0"><?php echo e($user->email); ?></p>
                    </div>
                </div>
                <div class="col-md-6 text-md-end mt-3 mt-md-0">
                    <span class="status-badge">
                        <i class="fas fa-clock me-2"></i>Miembro desde <?php echo e($user->created_at->format('M Y')); ?>

                    </span>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Información del Perfil -->
            <div class="col-md-6 mb-4">
                <div class="profile-card">
                    <h3><i class="fas fa-user"></i>Información del Perfil</h3>
                    <form method="post" action="<?php echo e(route('profile.update')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('patch'); ?>
                        
                        <div class="mb-3">
                            <label class="form-label">Nombre</label>
                            <input type="text" class="form-control" name="name" value="<?php echo e(old('name', $user->name)); ?>" required>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label">Correo Electrónico</label>
                            <input type="email" class="form-control" value="<?php echo e($user->email); ?>" readonly>
                            <small class="text-muted">El correo electrónico no se puede cambiar</small>
                        </div>

                        <button type="submit" class="btn btn-primary btn-custom">
                            <i class="fas fa-save me-2"></i>Guardar Cambios
                        </button>
                    </form>
                </div>
            </div>

            <!-- Cambiar Contraseña -->
            <div class="col-md-6 mb-4">
                <div class="profile-card">
                    <h3><i class="fas fa-lock"></i>Cambiar Contraseña</h3>
                    <form method="post" action="<?php echo e(route('password.update')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        
                        <div class="mb-3">
                            <label class="form-label">Contraseña Actual</label>
                            <input type="password" class="form-control" name="current_password" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Nueva Contraseña</label>
                            <input type="password" class="form-control" name="password" required>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label">Confirmar Nueva Contraseña</label>
                            <input type="password" class="form-control" name="password_confirmation" required>
                        </div>

                        <button type="submit" class="btn btn-primary btn-custom">
                            <i class="fas fa-key me-2"></i>Actualizar Contraseña
                        </button>
                    </form>
                </div>
            </div>

            <!-- Eliminar Cuenta -->
            <div class="col-12">
                <div class="profile-card">
                    <div class="danger-zone">
                        <h3 class="text-danger"><i class="fas fa-exclamation-triangle"></i>Eliminar Cuenta</h3>
                        <p class="text-muted mb-4">Una vez que elimines tu cuenta, todos tus datos serán eliminados permanentemente.</p>
                        <button class="btn btn-danger btn-custom" data-bs-toggle="modal" data-bs-target="#deleteAccountModal">
                            <i class="fas fa-trash-alt me-2"></i>Eliminar mi cuenta
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Eliminar Cuenta -->
    <div class="modal fade" id="deleteAccountModal" tabindex="-1" aria-labelledby="deleteAccountModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteAccountModalLabel">Confirmar Eliminación de Cuenta</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="post" action="<?php echo e(route('profile.destroy')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <div class="modal-body">
                        <p>Por favor, ingresa tu contraseña para confirmar:</p>
                        <input type="password" class="form-control" name="password" required>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-danger">Eliminar Cuenta</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php if(session('status')): ?>
    <script>
        // Mostrar notificación de éxito
        window.onload = function() {
            const toast = new bootstrap.Toast(document.createElement('div'));
            toast.show();
        }
    </script>
    <?php endif; ?>
</body>
</html><?php /**PATH /home/inventariohidroo/public_html/resources/views/profile/edit.blade.php ENDPATH**/ ?>