

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h2 class="mb-0 fs-4">
                <?php if(request()->has('inventario_id')): ?>
                    <i class="fas fa-exchange-alt me-2"></i> Movimientos de <?php echo e($movimientos->first()->inventario->nombre); ?>

                <?php else: ?>
                    <i class="fas fa-exchange-alt me-2"></i> Todos los Movimientos
                <?php endif; ?>
            </h2>
            <a href="<?php echo e(route('inventarios.index')); ?>" class="btn btn-light btn-sm">
                <i class="fas fa-arrow-left me-2"></i> Volver a Inventario
            </a>
        </div>
        <div class="card-body">
            <?php if($movimientos->isEmpty()): ?>
                <p class="text-muted fs-5">No hay movimientos registrados.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>Fecha</th>
                                <th>Elemento</th>
                                <th>Origen</th>
                                <th>Destino</th>
                                <th>Empleado Origen</th>
                                <th>Empleado Destino</th>
                                <th>Realizado por</th>
                                <th class="text-center">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $movimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($movimiento->fecha_movimiento->format('d/m/Y H:i')); ?></td>
                                    <td><?php echo e($movimiento->inventario->nombre); ?></td>
                                    <td><?php echo e($movimiento->ubicacionOrigen->nombre ?? 'N/A'); ?></td>
                                    <td><?php echo e($movimiento->ubicacionDestino->nombre ?? 'N/A'); ?></td>
                                    <td><?php echo e($movimiento->usuarioOrigen->nombre); ?></td>
                                    <td><?php echo e($movimiento->usuarioDestino->nombre); ?></td>
                                    <td><?php echo e($movimiento->realizadoPor->name); ?></td>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('movimientos.show', $movimiento)); ?>" class="btn btn-outline-info btn-sm">
                                            <i class="fas fa-eye me-1"></i> Ver
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="d-flex justify-content-center mt-4">
                    <?php echo e($movimientos->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/inventariohidroo/public_html/resources/views/movimientos/index.blade.php ENDPATH**/ ?>