

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="row mb-4">
        <div class="col-12">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-white text-black py-3">
                    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                        <h1 class="h3 mb-0 text-gray-800">Gestión de Inventario</h1>
                        <?php if(auth()->user()->role->name === 'administrador'): ?>
                            <div class="d-flex gap-2">
                                <a href="<?php echo e(route('inventarios.create')); ?>" class="btn btn-primary btn-sm">
                                    <i class="fas fa-plus fa-sm me-2"></i>Añadir nuevo elemento
                                </a>
                                <a href="<?php echo e(route('inventarios.import.form')); ?>" class="btn btn-primary btn-sm">
                                    <i class="fas fa-file-import me-2"></i>Importar Inventario
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body">
                    <!-- Formulario de búsqueda -->
                    <div class="card shadow-sm border-0 mb-4">
                        <div class="card-body">
                            <!-- Contenedor de búsqueda con IA -->
                            <div id="aiSearchContainer" style="display: none;" class="mb-3">
                                <div class="input-group">
                                    <span class="input-group-text bg-primary text-white">
                                        <i class="fas fa-brain"></i>
                                    </span>
                                    <input type="text" class="form-control" id="aiQuery" 
                                           placeholder="Describe lo que buscas (ejemplo: 'herramientas en mantenimiento de la bodega principal')">
                                    <button class="btn btn-primary" type="button" id="askAI">
                                        <i class="fas fa-search"></i> Buscar
                                    </button>
                                </div>
                                <small class="form-text text-muted mt-2">
                                    <i class="fas fa-lightbulb me-1"></i>Puedes hacer preguntas como "¿Qué equipos están en mantenimiento?" o "Muestra las herramientas disponibles en bodega"
                                </small>
                            </div>

                            <!-- Contenedor de resultados de IA -->
                            <div id="aiResults" class="mb-4" style="display: none;">
                                <div class="card border-primary">
                                    <div class="card-header bg-primary text-white">
                                        <i class="fas fa-robot me-2"></i>Resultados de búsqueda inteligente
                                    </div>
                                    <div class="card-body">
                                        <div id="aiExplanation" class="alert alert-info">
                                            <!-- La explicación irá aquí -->
                                        </div>
                                        <div id="aiSuggestion" class="alert alert-warning" style="display: none;">
                                            <!-- Las sugerencias irán aquí -->
                                        </div>
                                        <div id="aiResultsTable" class="table-responsive">
                                            <!-- La tabla de resultados irá aquí -->
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Formulario de búsqueda manual -->
                            <div id="regularSearchContainer">
                                <form id="searchForm" action="<?php echo e(route('inventarios.index')); ?>" method="GET">
                                <div class="row g-3">
                                        <div class="col-12">
                                            <div class="input-group">
                                                <span class="input-group-text bg-primary text-white">
                                                    <i class="fas fa-search"></i>
                                                </span>
                                                <input type="text" class="form-control" id="search" name="search" 
                                                       placeholder="Buscar..." value="<?php echo e(request('search')); ?>">
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-6 col-lg-4">
                                            <div class="input-group">
                                                <span class="input-group-text"><i class="fas fa-folder"></i></span>
                                                <select id="categoria" name="categoria" class="form-select">
                                                    <option value="">Categoría</option>
                                                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($categoria->id); ?>" 
                                                            <?php echo e(request('categoria') == $categoria->id ? 'selected' : ''); ?>>
                                                            <?php echo e($categoria->nombre); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-6 col-lg-4">
                                            <div class="input-group">
                                                <span class="input-group-text"><i class="fas fa-box"></i></span>
                                                <select id="elemento" name="elemento" class="form-select" disabled>
                                                    <option value="">Elemento</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-6 col-lg-4">
                                            <div class="input-group">
                                                <span class="input-group-text"><i class="fas fa-tag"></i></span>
                                                <select id="marca" name="marca" class="form-select">
                                                    <option value="">Marca</option>
                                                    <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($marca); ?>" 
                                                            <?php echo e(request('marca') == $marca ? 'selected' : ''); ?>>
                                                            <?php echo e($marca); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-6 col-lg-4">
                                            <div class="input-group">
                                                <span class="input-group-text">
                                                    <i class="fas fa-map-marker-alt"></i>
                                                </span>
                                                <select id="ubicacion_id" name="ubicacion_id" class="form-select">
                                                    <option value="">Ubicación</option>
                                                    <?php $__currentLoopData = $ubicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $nombre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($id); ?>" 
                                                            <?php echo e(request('ubicacion_id') == $id ? 'selected' : ''); ?>>
                                                            <?php echo e($nombre); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-6 col-lg-4">
                                            <div class="input-group">
                                                <span class="input-group-text">
                                                    <i class="fas fa-info-circle"></i>
                                                </span>
                                                <select id="estado" name="estado" class="form-select">
                                                    <option value="">Estado</option>
                                                    <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($estado); ?>" 
                                                            <?php echo e(request('estado') == $estado ? 'selected' : ''); ?>>
                                                            <?php echo e(ucfirst($estado)); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <button type="button" class="btn btn-secondary w-100" id="limpiarFiltros">
                                                <i class="fas fa-undo me-2"></i>Limpiar filtros
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- Resultados del inventario -->
                    <div id="results">
                        <div class="accordion" id="accordionInventario">
                            <?php $__currentLoopData = $inventariosPorCategoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="accordion-item mb-3">
                                    <h2 class="accordion-header" id="heading<?php echo e($index); ?>">
                                        <button class="accordion-button collapsed" type="button" 
                                                data-bs-toggle="collapse" 
                                                data-bs-target="#collapse<?php echo e($index); ?>" 
                                                aria-expanded="false" 
                                                aria-controls="collapse<?php echo e($index); ?>">
                                            <i class="fas fa-folder me-2"></i><?php echo e($categoria['categoria']); ?>

                                        </button>
                                    </h2>
                                    <div id="collapse<?php echo e($index); ?>" 
                                         class="accordion-collapse collapse" 
                                         aria-labelledby="heading<?php echo e($index); ?>" 
                                         data-bs-parent="#accordionInventario">
                                        <div class="accordion-body">
                                            <div class="inventory-stats mb-3">
                                                <span class="badge bg-info">
                                                    <i class="fas fa-cubes"></i> Total: <?php echo e($categoria['conteos']->total); ?>

                                                </span>
                                                <span class="badge bg-success">
                                                    <i class="fas fa-check"></i> Disponibles: <?php echo e($categoria['conteos']->disponibles); ?>

                                                </span>
                                                <span class="badge bg-primary">
                                                    <i class="fas fa-hand-paper"></i> En uso: <?php echo e($categoria['conteos']->en_uso); ?>

                                                </span>
                                                <span class="badge bg-warning">
                                                    <i class="fas fa-tools"></i> En mant.: <?php echo e($categoria['conteos']->en_mantenimiento); ?>

                                                </span>
                                                <span class="badge bg-danger">
                                                    <i class="fas fa-ban"></i> Dados de baja: <?php echo e($categoria['conteos']->dados_de_baja); ?>

                                                </span>
                                                <span class="badge bg-dark">
                                                    <i class="fas fa-exclamation-triangle"></i> Robados: <?php echo e($categoria['conteos']->robados); ?>

                                                </span>
                                            </div>
                                            <div class="table-responsive">
                                                <table class="table table-hover table-striped">
                                                    <thead>
                                                        <tr>
                                                            <th class="text-center fw-bold">Código</th>
                                                            <th class="text-center fw-bold">Nombre</th>
                                                            <th class="text-center fw-bold">Marca</th>
                                                            <th class="text-center fw-bold">Serial</th>
                                                            <th class="text-center fw-bold">Cantidad</th>
                                                            <th class="text-center fw-bold">Ubicación y Estado</th>
                                                            <th class="text-center fw-bold">Acciones</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__empty_1 = true; $__currentLoopData = $categoria['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <tr>
                                                                <td class="text-center"><?php echo e($item->codigo_unico); ?></td>
                                                                <td class="text-center"><?php echo e($item->nombre); ?></td>
                                                                <td class="text-center"><?php echo e($item->marca); ?></td>
                                                                <td class="text-center"><?php echo e($item->numero_serie); ?></td>
                                                                <td class="text-center"><?php echo e($item->ubicaciones->sum('cantidad')); ?></td>
                                                                <td class="text-center">
                                                                    <?php $__currentLoopData = $item->ubicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ubicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <div class="mb-1">
                                                                            <strong><?php echo e($ubicacion->ubicacion->nombre); ?>:</strong> 
                                                                            <?php echo e($ubicacion->cantidad); ?>

                                                                            <span class="badge bg-<?php echo e($ubicacion->estado == 'disponible' ? 'success' : ($ubicacion->estado == 'en uso' ? 'primary' : ($ubicacion->estado == 'en mantenimiento' ? 'warning' : ($ubicacion->estado == 'robado' ? 'dark' : 'danger')))); ?>">
                                                                                <?php echo e(ucfirst($ubicacion->estado)); ?>

                                                                            </span>
                                                                        </div>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </td>
                                                                <td class="text-center">
                                                                    <div class="btn-group" role="group">
                                                                        <a href="<?php echo e(route('inventarios.show', $item)); ?>" 
                                                                           class="btn btn-outline-info btn-sm">
                                                                            <i class="fas fa-eye"></i>
                                                                        </a>
                                                                        <?php if(auth()->user()->role->name === 'administrador'): ?>
                                                                            <a href="<?php echo e(route('inventarios.edit', $item)); ?>" 
                                                                               class="btn btn-outline-warning btn-sm">
                                                                                <i class="fas fa-edit"></i>
                                                                            </a>
                                                                            <button type="button" 
                                                                                    class="btn btn-outline-danger btn-sm delete-item" 
                                                                                    data-item-id="<?php echo e($item->id); ?>">
                                                                                <i class="fas fa-trash"></i>
                                                                            </button>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            <tr>
                                                                <td colspan="7" class="text-center">
                                                                    No se encontraron elementos en esta categoría.
                                                                </td>
                                                            </tr>
                                                        <?php endif; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal de confirmación para eliminar -->
<div class="modal fade" id="deleteConfirmModal" tabindex="-1" aria-labelledby="deleteConfirmModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteConfirmModalLabel">Confirmar eliminación</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                ¿Estás seguro de que quieres eliminar este elemento? Esta acción no se puede deshacer.
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <form id="deleteForm" action="" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Eliminar</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .badge {
        font-size: 0.8rem;
    }
    .accordion-button:not(.collapsed) {
        background-color: #f8f9fa;
        color: #0d6efd;
    }
    .table th, .table td {
        vertical-align: middle;
    }
    .table thead th {
        font-weight: bold;
    }
    .input-group-text {
        background-color: #f8f9fa;
        border-right: none;
    }
    .form-control, .form-select {
        border-left: none;
    }
    .form-control:focus, .form-select:focus {
        box-shadow: none;
        border-color: #ced4da;
    }
    .input-group:hover .input-group-text,
    .input-group:hover .form-control,
    .input-group:hover .form-select {
        border-color: #0d6efd;
    }
    .btn-secondary {
        background-color: #6c757d;
        border-color: #6c757d;
    }
    .btn-secondary:hover {
        background-color: #5a6268;
        border-color: #545b62;
    }

    /* Estilos para la búsqueda con IA */
    .form-check-input:checked {
        background-color: #0d6efd;
        border-color: #0d6efd;
    }

    #aiSearchContainer .input-group {
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    #aiSearchContainer .form-control:focus {
        border-color: #0d6efd;
        box-shadow: none;
    }

    #aiResults {
        transition: all 0.3s ease;
    }

    #aiResults .card {
        border: none;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    #aiExplanation, #aiSuggestion {
        margin-bottom: 1rem;
    }

    .alert i {
        margin-right: 0.5rem;
    }

    #aiResultsTable .table {
        margin-bottom: 0;
    }

    .inventory-stats {
        display: flex;
        flex-wrap: wrap;
        gap: 0.5rem;
    }
    .inventory-stats .badge {
        font-size: 1rem !important;
        padding: 0.5em 0.6em !important;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 120px;
    }
    .inventory-stats .badge i {
        font-size: 1.2em;
        margin-right: 0.3em;
    }

    @media (max-width: 768px) {
        .btn-group {
            display: flex;
            flex-direction: column;
        }
        .btn-group .btn {
            margin-bottom: 0.25rem;
        }
        .table-responsive {
            font-size: 0.9rem;
        }
        .btn-group .btn {
            padding: 0.25rem 0.5rem;
            font-size: 0.75rem;
        }
        .input-group {
            margin-bottom: 0.5rem;
        }
        .inventory-stats .badge {
            font-size: 0.9rem !important;
            min-width: 100px;
        }
    }

    /* Animación para el spinner de carga */
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }

    .fa-spin {
        animation: spin 1s linear infinite;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const categoriaSelect = document.getElementById('categoria');
    const elementoSelect = document.getElementById('elemento');

    // Manejo de elementos por categoría
    categoriaSelect.addEventListener('change', function() {
        const categoriaId = this.value;
        elementoSelect.disabled = true;
        elementoSelect.innerHTML = '<option value="">Cargando...</option>';

        if (categoriaId) {
            fetch(`/inventarios/elementos-por-categoria/${categoriaId}`)
                .then(response => response.json())
                .then(data => {
                    elementoSelect.innerHTML = '<option value="">Elemento</option>';
                    data.forEach(elemento => {
                        const option = document.createElement('option');
                        option.value = elemento.nombre;
                        option.textContent = elemento.nombre;
                        elementoSelect.appendChild(option);
                    });
                    elementoSelect.disabled = false;
                })
                .catch(error => {
                    console.error('Error:', error);
                    elementoSelect.innerHTML = '<option value="">Error al cargar elementos</option>';
                });
        } else {
            elementoSelect.innerHTML = '<option value="">Elemento</option>';
            elementoSelect.disabled = true;
        }
    });

    // Función para actualizar resultados
    function updateResults(isClearing = false) {
        const form = document.getElementById('searchForm');
        const url = form.action;
        const searchData = isClearing ? '' : new URLSearchParams(new FormData(form));

        fetch(`${url}${isClearing ? '' : '?' + searchData.toString()}`, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.text())
        .then(html => {
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');
            const results = doc.getElementById('results');
            
            if (results) {
                document.getElementById('results').innerHTML = results.innerHTML;
            }

            if (isClearing) {
                document.querySelectorAll('.accordion-collapse').forEach(el => {
                    el.classList.remove('show');
                });
                history.pushState(null, '', url);
            } else {
                document.querySelectorAll('.accordion-collapse').forEach(el => {
                    el.classList.add('show');
                });
                history.pushState(null, '', `${url}${searchData.toString() ? '?' + searchData.toString() : ''}`);
            }
        })
        .catch(error => console.error('Error:', error));
    }

    // Event listeners para la búsqueda
    document.querySelectorAll('#searchForm select, #searchForm input').forEach(el => {
        el.addEventListener('change', () => updateResults());
    });

    document.getElementById('searchForm').addEventListener('submit', function(e) {
        e.preventDefault();
        updateResults();
    });

    // Limpiar filtros
    document.getElementById('limpiarFiltros').addEventListener('click', function() {
        document.getElementById('searchForm').reset();
        elementoSelect.innerHTML = '<option value="">Elemento</option>';
        elementoSelect.disabled = true;
        updateResults(true);
    });

    // Modal de confirmación para eliminar
    document.addEventListener('click', function(e) {
        const deleteButton = e.target.closest('.delete-item');
        if (deleteButton) {
            e.preventDefault();
            const itemId = deleteButton.getAttribute('data-item-id');
            const deleteForm = document.getElementById('deleteForm');
            deleteForm.action = `/inventarios/${itemId}`;
            
            const modal = new bootstrap.Modal(document.getElementById('deleteConfirmModal'));
            modal.show();
        }
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/inventariohidroo/public_html/resources/views/inventarios/index.blade.php ENDPATH**/ ?>